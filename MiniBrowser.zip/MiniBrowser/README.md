# Mini Browser (GeckoView + uBlock Origin)

Android mini browser on Firefox's Gecko engine. Opens YouTube, blocks ads with a
built-in uBlock Origin, and lets you install other Firefox extensions from an .xpi link.

## Build with GitHub Actions
1. Create a new GitHub repo and upload everything from this zip (keep the `.github` folder).
2. Push to `main`. Open the **Actions** tab > **Build APK**.
3. When it finishes, download the **MiniBrowser-debug-apk** artifact, unzip, install the APK.
   (Or run it manually: Actions > Build APK > Run workflow.)

## Notes
- The workflow downloads uBlock Origin from addons.mozilla.org at build time.
- Engine version is set in `gradle.properties` (`geckoVersion`). If the build fails on
  GeckoView API changes, keep it at 128.+.
- Add-ons button: paste a direct .xpi URL to install more extensions.
- Debug APK is fine for personal use. For release, add a signing key.

## Features
- Home button, full-screen button (hides the search bar; tap the small corner button to bring it back).
- Add-ons button: see installed add-ons, remove them, add popular ones or any .xpi link.
- Logins/cookies (e.g. Google account) and the last opened page are saved on the device.
