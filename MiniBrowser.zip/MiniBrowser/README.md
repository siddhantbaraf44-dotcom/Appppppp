# Mini Browser (GeckoView + uBlock Origin)

Android browser on Firefox's Gecko engine with a built-in YouTube ad blocker.

## Build with GitHub Actions
1. Upload this zip (unextracted) to a GitHub repo together with `.github/workflows/build.yml`.
2. Actions > Build APK from ZIP builds it. Download the APK from Artifacts.

## Features
- Modern light/dark UI (follows system theme). Top bar: Home, address bar, Tabs, Menu. Back = system back gesture
- Background play (Settings > Background play): keeps audio going when the app is minimised
- Multiple tabs, private tabs, links that open in new tabs
- Bookmarks, history, find in page, desktop site, share, full screen
- Search engine choice (DuckDuckGo / Google / Bing / Brave)
- Add-ons manager (uBlock Origin built in; install/remove others, popular picks)
- Cookies/logins (e.g. Google account) and last page saved on device
- Can be set as a default browser (opens http/https links from other apps)
