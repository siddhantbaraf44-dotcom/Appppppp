# Ice (GeckoView + uBlock Origin)

Android browser on Firefox's Gecko engine with a built-in YouTube ad blocker.

## Build with GitHub Actions
1. Upload this zip (unextracted) to a GitHub repo together with `.github/workflows/build.yml`.
2. Actions > Build APK from ZIP builds it. Download the APK from Artifacts.

## Features
- Modern light/dark UI (follows system theme). Chrome-style top bar: Home, address bar, Tabs, Menu (popup menu, tab grid). Back = system back gesture
- Background play (Settings > Background play): keeps audio going when the app is minimised
- Pull down to refresh. Home button opens a home page you set (Menu > Settings > Home page)
- Chrome-style tab strip (favicon, title, ×, +, highlighted active tab), tab switcher grid with tab-count badge, private tabs, links that open in new tabs
- Chrome-order three-dot menu (New tab, Incognito, History, Delete browsing data, Downloads, Bookmarks, Share, Find in page, Desktop site, Full screen, Add-ons, Settings)
- No default home page: set your own in Settings > Home page (saved between sessions)
- Full screen stays on when Back is pressed; only the exit button leaves it
- Bookmarks, history, find in page, desktop site, share, full screen
- Search engine choice (DuckDuckGo / Google / Bing / Brave)
- Add-ons manager (uBlock Origin built in; install/remove others, popular picks)
- Cookies/logins (e.g. Google account) and last page saved on device
- Can be set as a default browser (opens http/https links from other apps)
- Search-engine dropdown in the address bar (DuckDuckGo, Google, Bing, Brave, Yahoo, Ecosia, Startpage, YouTube, Wikipedia)
- Home page with your own shortcuts (logos fetched from each site); long-press a shortcut to edit/remove
- Search suggestions from the selected engine while typing (off in Incognito; toggle in Settings)
- Extensions saved to Firebase Realtime Database and restored on a fresh install
- Ice home page (teal gradient, wordmark, search pill with engine selector, shortcuts card), vertical favicon tab sidebar (long-press a tab to close)
