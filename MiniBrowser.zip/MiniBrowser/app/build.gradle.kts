plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val geckoVersion: String by project

android {
    namespace = "com.example.minibrowser"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.minibrowser"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging { jniLibs { useLegacyPackaging = true } }
}

dependencies {
    implementation("org.mozilla.geckoview:geckoview-omni:$geckoVersion")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
}
