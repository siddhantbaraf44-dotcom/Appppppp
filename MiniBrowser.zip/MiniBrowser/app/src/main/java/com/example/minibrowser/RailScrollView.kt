package com.example.minibrowser

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.ScrollView

/**
 * Scroll container for the floating half-pill tabs. It only takes touches that land
 * on a button (including its slide offset); gaps and everything else fall through to the page.
 */
class RailScrollView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : ScrollView(context, attrs) {

    /** True when (x, y) in this view's coordinates is on a button. */
    fun hitsButton(x: Float, y: Float): Boolean {
        val col = getChildAt(0) as? ViewGroup ?: return false
        val cy = y + scrollY
        for (i in 0 until col.childCount) {
            val c = col.getChildAt(i)
            if (c.visibility != VISIBLE) continue
            val l = c.left + c.translationX
            val r = c.right + c.translationX
            if (x >= l && x <= r && cy >= c.top && cy <= c.bottom) return true
        }
        return false
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && !hitsButton(ev.x, ev.y)) return false
        return super.dispatchTouchEvent(ev)
    }
}
