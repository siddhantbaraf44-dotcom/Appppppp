package com.example.minibrowser

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class CloudExt(val id: String, val name: String, val url: String)

/**
 * Stores the list of installed extensions in Firebase Realtime Database through its REST API
 * (no Firebase SDK / google-services.json needed). Data lives at
 *   /minibrowser/extensions/<key> = { id, name, url }
 * and is readable/writable only by the signed-in owner (see the database rules).
 */
class CloudSync(private val store: Store) {
    private val dbUrl = "https://memme-e5686-default-rtdb.firebaseio.com"

    fun configured() = true

    fun reset() {}

    private fun http(method: String, url: String, body: String?): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = method
        c.connectTimeout = 10000
        c.readTimeout = 10000
        if (body != null) {
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        }
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
        c.disconnect()
        if (code !in 200..299) {
            val msg = try {
                val o = JSONObject(text)
                val e = o.opt("error")
                if (e is JSONObject) e.optString("message") else e?.toString()
            } catch (_: Exception) { null }
            throw RuntimeException(msg ?: "HTTP $code")
        }
        return text
    }

    private fun node(path: String) = "$dbUrl/minibrowser/$path.json"

    // Realtime Database keys cannot contain . $ # [ ] /
    private fun key(id: String) = id.replace(Regex("[.$#\\[\\]/]"), "_")

    fun saveExtension(id: String, name: String, url: String) {
        val v = JSONObject().put("id", id).put("name", name).put("url", url).toString()
        http("PUT", node("extensions/${key(id)}"), v)
    }

    fun removeExtension(id: String) {
        http("DELETE", node("extensions/${key(id)}"), null)
    }

    fun loadExtensions(): List<CloudExt> {
        val text = http("GET", node("extensions"), null).trim()
        if (text == "null" || text.isEmpty()) return emptyList()
        val o = JSONObject(text)
        val out = mutableListOf<CloudExt>()
        for (k in o.keys()) {
            val e = o.optJSONObject(k) ?: continue
            val id = e.optString("id")
            val url = e.optString("url")
            if (id.isNotEmpty() && url.isNotEmpty()) out.add(CloudExt(id, e.optString("name", id), url))
        }
        return out
    }
}
