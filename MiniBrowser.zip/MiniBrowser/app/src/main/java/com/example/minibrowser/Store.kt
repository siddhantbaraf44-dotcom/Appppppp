package com.example.minibrowser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Entry(val title: String, val url: String)

/** Small on-device storage for bookmarks, history and settings. */
class Store(context: Context) {
    private val p = context.getSharedPreferences("minibrowser_data", Context.MODE_PRIVATE)

    companion object {
        val ENGINES = linkedMapOf(
            "DuckDuckGo" to "https://duckduckgo.com/?q=%s",
            "Google" to "https://www.google.com/search?q=%s",
            "Bing" to "https://www.bing.com/search?q=%s",
            "Brave" to "https://search.brave.com/search?q=%s"
        )
        private const val K_BOOKMARKS = "bookmarks"
        private const val K_HISTORY = "history"
        private const val K_ENGINE = "engine"
        private const val K_LAST = "last_url"
    }

    private fun read(key: String): MutableList<Entry> {
        val out = mutableListOf<Entry>()
        try {
            val arr = JSONArray(p.getString(key, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Entry(o.optString("t"), o.optString("u")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun write(key: String, list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.title).put("u", it.url)) }
        p.edit().putString(key, arr.toString()).apply()
    }

    // Bookmarks
    fun bookmarks(): List<Entry> = read(K_BOOKMARKS)
    fun isBookmarked(url: String) = read(K_BOOKMARKS).any { it.url == url }
    fun addBookmark(title: String, url: String) {
        val l = read(K_BOOKMARKS)
        if (l.none { it.url == url }) {
            l.add(0, Entry(if (title.isBlank()) url else title, url))
            write(K_BOOKMARKS, l)
        }
    }
    fun removeBookmark(url: String) = write(K_BOOKMARKS, read(K_BOOKMARKS).filter { it.url != url })

    // History (newest first)
    fun history(): List<Entry> = read(K_HISTORY)
    fun addHistory(title: String, url: String) {
        val l = read(K_HISTORY)
        l.removeAll { it.url == url }
        l.add(0, Entry(if (title.isBlank()) url else title, url))
        write(K_HISTORY, l.take(300))
    }
    fun clearHistory() = write(K_HISTORY, emptyList())

    // Settings
    fun engineName(): String = p.getString(K_ENGINE, "DuckDuckGo") ?: "DuckDuckGo"
    fun setEngine(name: String) = p.edit().putString(K_ENGINE, name).apply()
    fun searchUrl(query: String): String {
        val tpl = ENGINES[engineName()] ?: ENGINES.getValue("DuckDuckGo")
        return tpl.replace("%s", java.net.URLEncoder.encode(query, "UTF-8"))
    }

    fun lastUrl(): String? = p.getString(K_LAST, null)
    fun setLastUrl(url: String) = p.edit().putString(K_LAST, url).apply()
}
