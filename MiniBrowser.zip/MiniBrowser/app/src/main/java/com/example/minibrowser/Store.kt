package com.example.minibrowser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Entry(val title: String, val url: String)

/** Small on-device storage for bookmarks, history and settings. */
class Store(context: Context) {
    private val p = context.getSharedPreferences("minibrowser_data", Context.MODE_PRIVATE)

    companion object {
        val ENGINES = linkedMapOf(
            "DuckDuckGo" to "https://duckduckgo.com/?q=%s",
            "Google" to "https://www.google.com/search?q=%s",
            "Bing" to "https://www.bing.com/search?q=%s",
            "Brave" to "https://search.brave.com/search?q=%s",
            "Yahoo" to "https://search.yahoo.com/search?p=%s",
            "Ecosia" to "https://www.ecosia.org/search?q=%s",
            "Startpage" to "https://www.startpage.com/do/search?q=%s",
            "YouTube" to "https://m.youtube.com/results?search_query=%s",
            "Wikipedia" to "https://en.wikipedia.org/w/index.php?search=%s"
        )

        // Suggestion endpoints (all return OpenSearch JSON: ["query", ["suggestion", ...]])
        val SUGGEST = mapOf(
            "DuckDuckGo" to "https://duckduckgo.com/ac/?type=list&q=%s",
            "Google" to "https://suggestqueries.google.com/complete/search?client=firefox&q=%s",
            "Bing" to "https://api.bing.com/osjson.aspx?query=%s",
            "Brave" to "https://search.brave.com/api/suggest?q=%s",
            "Yahoo" to "https://search.yahoo.com/sugg/gossip/gossip-us-ff/?output=fxjson&command=%s",
            "Ecosia" to "https://ac.ecosia.org/autocomplete?type=list&q=%s",
            "Startpage" to "https://duckduckgo.com/ac/?type=list&q=%s",
            "YouTube" to "https://suggestqueries.google.com/complete/search?client=firefox&ds=yt&q=%s",
            "Wikipedia" to "https://en.wikipedia.org/w/api.php?action=opensearch&limit=8&search=%s"
        )

        fun engineHost(name: String): String {
            val tpl = ENGINES[name] ?: ENGINES.getValue("DuckDuckGo")
            return tpl.substringAfter("://").substringBefore("/")
        }
        val DEFAULT_SHORTCUTS = listOf(
            Entry("Google", "https://www.google.com"),
            Entry("Booking", "https://www.booking.com"),
            Entry("Skyscanner", "https://www.skyscanner.com"),
            Entry("Hotwire", "https://www.hotwire.com"),
            Entry("iHerb", "https://www.iherb.com"),
            Entry("YouTube", "https://m.youtube.com"),
            Entry("Maps", "https://maps.google.com")
        )
        const val DEFAULT_HOME = "" // no built-in home page: the user sets their own
        private const val K_BOOKMARKS = "bookmarks"
        private const val K_HISTORY = "history"
        private const val K_ENGINE = "engine"
        private const val K_LAST = "last_url"
        private const val K_SHORTCUTS = "shortcuts"
        private const val K_SUGGEST = "suggest"
        private const val K_SYNC_EMAIL = "sync_email"
        private const val K_SYNC_PASS = "sync_pass"
    }

    private fun read(key: String): MutableList<Entry> {
        val out = mutableListOf<Entry>()
        try {
            val arr = JSONArray(p.getString(key, "[]"))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Entry(o.optString("t"), o.optString("u")))
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun write(key: String, list: List<Entry>) {
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("t", it.title).put("u", it.url)) }
        p.edit().putString(key, arr.toString()).apply()
    }

    // Bookmarks
    fun bookmarks(): List<Entry> = read(K_BOOKMARKS)
    fun isBookmarked(url: String) = read(K_BOOKMARKS).any { it.url == url }
    fun addBookmark(title: String, url: String) {
        val l = read(K_BOOKMARKS)
        if (l.none { it.url == url }) {
            l.add(0, Entry(if (title.isBlank()) url else title, url))
            write(K_BOOKMARKS, l)
        }
    }
    fun removeBookmark(url: String) = write(K_BOOKMARKS, read(K_BOOKMARKS).filter { it.url != url })

    // Home-screen shortcuts (the logo is fetched from the link's website)
    fun shortcuts(): List<Entry> =
        if (p.contains(K_SHORTCUTS)) read(K_SHORTCUTS) else DEFAULT_SHORTCUTS
    fun saveShortcuts(list: List<Entry>) = write(K_SHORTCUTS, list)

    // History (newest first)
    fun history(): List<Entry> = read(K_HISTORY)
    @Synchronized
    fun addHistory(title: String, url: String) {
        val l = read(K_HISTORY)
        l.removeAll { it.url == url }
        l.add(0, Entry(if (title.isBlank()) url else title, url))
        write(K_HISTORY, l.take(300))
    }
    fun clearHistory() = write(K_HISTORY, emptyList())

    // Settings
    fun suggestUrl(): String = SUGGEST[engineName()] ?: SUGGEST.getValue("DuckDuckGo")
    fun suggestOn(): Boolean = p.getBoolean(K_SUGGEST, true)
    fun setSuggestOn(v: Boolean) = p.edit().putBoolean(K_SUGGEST, v).apply()

    // Firebase sign-in used by CloudSync (personal app: one user)
    fun syncEmail(): String = p.getString(K_SYNC_EMAIL, "") ?: ""
    fun syncPass(): String = p.getString(K_SYNC_PASS, "") ?: ""
    fun setSync(email: String, pass: String) =
        p.edit().putString(K_SYNC_EMAIL, email).putString(K_SYNC_PASS, pass).apply()

    fun engineName(): String = p.getString(K_ENGINE, "DuckDuckGo") ?: "DuckDuckGo"
    fun setEngine(name: String) = p.edit().putString(K_ENGINE, name).apply()
    fun searchUrl(query: String): String {
        val tpl = ENGINES[engineName()] ?: ENGINES.getValue("DuckDuckGo")
        return tpl.replace("%s", java.net.URLEncoder.encode(query, "UTF-8"))
    }

    // Background play (keeps audio/video going when the app is minimised)
    fun bgPlay(): Boolean = p.getBoolean("bg_play", true)
    fun setBgPlay(on: Boolean) = p.edit().putBoolean("bg_play", on).apply()

    // Home page chosen by the user (opened by the Home button and on startup). Saved in SharedPreferences,
    // so it persists between sessions. Empty = not set yet.
    fun homeUrl(): String = p.getString("home_url", DEFAULT_HOME) ?: DEFAULT_HOME
    fun setHomeUrl(url: String) = p.edit().putString("home_url", url).apply()

    fun lastUrl(): String? = p.getString(K_LAST, null)
    fun setLastUrl(url: String) = p.edit().putString(K_LAST, url).apply()
}
