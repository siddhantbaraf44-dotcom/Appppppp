package com.example.minibrowser

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.app.Dialog
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioManager
import android.os.Environment
import android.util.LruCache
import android.webkit.URLUtil
import android.widget.CheckBox
import java.net.HttpURLConnection
import java.net.URL
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupWindow
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import java.lang.reflect.InvocationHandler
import java.lang.reflect.ParameterizedType
import java.lang.reflect.Proxy
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoRuntimeSettings
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.StorageController
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController
import org.mozilla.geckoview.WebResponse

/** One browser tab = one GeckoSession plus the state the UI needs. */
class Tab(val session: GeckoSession, val isPrivate: Boolean) {
    var title = ""
    var url = ""
    var progress = 0
    var loading = false
    var canBack = false
    var canForward = false
    var desktop = false
    var scrollY = 0
    var pendingUrl: String? = null   // restored tab: loads when first shown
    var fromLink = false             // opened from a link in another tab
}

/** A row in a menu / sheet. */
data class Row(
    val title: String,
    val subtitle: String? = null,
    val icon: Int? = null,
    val trailingIcon: Int? = null,
    val onTrailing: (() -> Unit)? = null,
    val checked: Boolean? = null,      // shows a checkbox (e.g. Desktop site)
    val divider: Boolean = false,      // thin separator line instead of a row
    val onClick: () -> Unit = {}
)

class MainActivity : Activity() {

    companion object {
        private val RAIL_BG = Color.argb(199, 0x20, 0x21, 0x24)      // #202124 @ ~78%
        private val RAIL_BORDER = Color.argb(56, 255, 255, 255)      // white @ 22%
        private val RAIL_ACTIVE = Color.parseColor("#8AB4F8")
        private val RAIL_ICON_ACTIVE = Color.parseColor("#0B1F4B")   // dark navy
        private var runtime: GeckoRuntime? = null

        private const val MAX_SAVED_TABS = 20
        private const val RAIL_MAX_BOTTOM = 0.58f   // tab stack never reaches below this fraction of the screen height

        // uBlock Origin is unpacked into assets/extensions/ublock by the GitHub Action
        private const val UBLOCK_URI = "resource://android/assets/extensions/ublock/"
        private const val UBLOCK_ID = "uBlock0@raymondhill.net"

        private val POPULAR = listOf(
            "SponsorBlock" to "https://addons.mozilla.org/firefox/downloads/latest/sponsorblock/latest.xpi",
            "Return YouTube Dislike" to "https://addons.mozilla.org/firefox/downloads/latest/return-youtube-dislikes/latest.xpi",
            "Enhancer for YouTube" to "https://addons.mozilla.org/firefox/downloads/latest/enhancer-for-youtube/latest.xpi",
            "Dark Reader" to "https://addons.mozilla.org/firefox/downloads/latest/darkreader/latest.xpi"
        )
    }

    private val tabs = mutableListOf<Tab>()
    private var currentIndex = -1
    private val current: Tab? get() = tabs.getOrNull(currentIndex)

    private lateinit var store: Store
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var geckoView: GeckoView
    private lateinit var swipe: SwipeRefreshLayout
    private lateinit var topBar: View
    private lateinit var findBar: View
    private lateinit var urlText: EditText
    private lateinit var findInput: EditText
    private lateinit var lockIcon: ImageView
    private lateinit var reloadBtn: ImageButton
    private lateinit var progress: ProgressBar
    private lateinit var tabCount: TextView
    private lateinit var exitFullBtn: ImageButton
    private lateinit var menuBtn: View
    private lateinit var tabSidebar: RailScrollView
    private lateinit var tabSidebarCol: LinearLayout
    private lateinit var urlBar: View
    private lateinit var rootFrame: View
    private var homePillIcon: ImageView? = null
    private var homePillText: TextView? = null
    private var prevStatusColor = 0
    private lateinit var engineBtn: View
    private lateinit var engineIcon: ImageView
    private lateinit var newTab: View
    private lateinit var shortcutGrid: LinearLayout
    private var newTabShown = false
    private val suggestIo = java.util.concurrent.Executors.newSingleThreadExecutor()
    private var suggestJob: Runnable? = null
    private var suggestSeq = 0
    private var suppressSuggest = false
    private var suggestPopup: PopupWindow? = null
    private var suggestBox: LinearLayout? = null
    private val io = java.util.concurrent.Executors.newFixedThreadPool(2)       // favicons
    private val failedFavicons = java.util.Collections.synchronizedSet(HashSet<String>())
    private var bgServiceOn = false
    private val ioSerial = java.util.concurrent.Executors.newSingleThreadExecutor() // history writes

    private val favicons = LruCache<String, Bitmap>(64)
    private val pendingFavicons = java.util.Collections.synchronizedSet(HashSet<String>())
    private var lastStripSig = ""

    private var backGuard: Any? = null

    private var barHidden = false       // user chose "Full screen"
    private var videoFullscreen = false // a page/video went full screen

    // ------------------------------------------------------------------ Lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)

        geckoView = findViewById(R.id.geckoview)
        swipe = findViewById(R.id.swipe)
        topBar = findViewById(R.id.topBar)
        findBar = findViewById(R.id.findBar)
        urlText = findViewById(R.id.urlText)
        findInput = findViewById(R.id.findInput)
        lockIcon = findViewById(R.id.lockIcon)
        reloadBtn = findViewById(R.id.reloadBtn)
        progress = findViewById(R.id.progress)
        tabCount = findViewById(R.id.tabCount)
        exitFullBtn = findViewById(R.id.exitFullBtn)
        menuBtn = findViewById(R.id.menuBtn)
        tabSidebar = findViewById(R.id.tabSidebar)
        tabSidebarCol = findViewById(R.id.tabSidebarCol)
        val relayoutRail = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> positionRail() }
        topBar.addOnLayoutChangeListener(relayoutRail)
        findBar.addOnLayoutChangeListener(relayoutRail)
        urlBar = findViewById(R.id.urlBar)
        rootFrame = findViewById(R.id.rootFrame)
        rootFrame.addOnLayoutChangeListener(relayoutRail)
        prevStatusColor = window.statusBarColor
        engineBtn = findViewById(R.id.engineBtn)
        engineIcon = findViewById(R.id.engineIcon)
        newTab = findViewById(R.id.newTab)
        shortcutGrid = findViewById(R.id.shortcutGrid)
        engineBtn.setOnClickListener { showEnginePopup() }

        // The Gecko profile (cookies, logins, site storage) is kept on disk, so a
        // Google sign-in stays saved between launches. Private tabs are not saved.
        val rt = runtime ?: GeckoRuntime.create(
            applicationContext,
            GeckoRuntimeSettings.Builder()
                .consoleOutput(false)
                .remoteDebuggingEnabled(false)
                .build()
        ).also { runtime = it }
        setupExtensions(rt)
        setupListeners()

        // Pull down to refresh (only when the page is scrolled to the very top)
        swipe.setColorSchemeColors(getColor(R.color.accent))
        swipe.setProgressBackgroundColorSchemeColor(getColor(R.color.surface))
        swipe.setOnChildScrollUpCallback(SwipeRefreshLayout.OnChildScrollUpCallback { _, _ ->
            (current?.scrollY ?: 0) > 0
        })
        swipe.setOnRefreshListener {
            current?.session?.reload()
            handler.postDelayed({ swipe.isRefreshing = false }, 1200)
        }

        // Ask for the notification permission once (it is only needed for the background-play notification)
        if (android.os.Build.VERSION.SDK_INT >= 33 && store.bgPlay() && !store.notifAsked() &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED
        ) {
            store.setNotifAsked()
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        }

        restoreTabs(if (savedInstanceState == null) intent?.dataString else null)
    }

    /** Brings back the tabs from the last session (only the selected one loads right away). */
    private fun restoreTabs(link: String?) {
        val saved = store.savedTabs()
        if (saved.urls.isEmpty()) {
            openTab(link ?: store.homeUrl().ifBlank { null })
            return
        }
        saved.urls.forEachIndexed { i, u ->
            openTab(u, select = false, lazy = i != saved.selected)
        }
        selectTab(saved.selected)
        if (link != null) openTab(link)
    }

    private fun saveTabs() {
        val normal = tabs.filter { !it.isPrivate && it.url.startsWith("http") }
        var sel = normal.indexOf(current)
        var list = normal
        if (list.size > MAX_SAVED_TABS) {
            val drop = list.size - MAX_SAVED_TABS
            list = list.drop(drop)
            sel -= drop
        }
        store.saveTabs(list.map { it.url }, sel.coerceAtLeast(0))
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        intent?.dataString?.let { openTab(it) }
    }

    private fun audioPlaying() =
        try { (getSystemService(AUDIO_SERVICE) as AudioManager).isMusicActive } catch (_: Exception) { false }

    // Background play: keep the page "visible" to Gecko and run a foreground service so
    // Android doesn't freeze the app while audio is playing.
    private val keepActive = Runnable { current?.session?.setActive(true) }

    override fun onPause() {
        super.onPause()
        // Only start the foreground service when something is actually playing audio
        if (store.bgPlay() && !isFinishing && !isChangingConfigurations && audioPlaying()) {
            try {
                val i = Intent(this, BackgroundPlayService::class.java)
                if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                bgServiceOn = true
            } catch (_: Exception) {
            }
        }
    }

    override fun onStop() {
        super.onStop()
        saveTabs()
        if (bgServiceOn) {
            handler.postDelayed(keepActive, 400)
            handler.postDelayed(keepActive, 2000)
        }
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(keepActive)
        if (bgServiceOn) {
            stopService(Intent(this, BackgroundPlayService::class.java))
            bgServiceOn = false
        }
        verifyDisplayedTab()
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) favicons.evictAll()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        dismissSuggest()
        setBackGuard(false)
        io.shutdownNow()
        suggestIo.shutdownNow()
        ioSerial.shutdown()
        geckoView.releaseSession()
        tabs.forEach { try { it.session.close() } catch (_: Exception) {} }
        tabs.clear()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        handleBack(allowExit = true)
    }

    private fun isFullScreen() = barHidden || videoFullscreen

    /**
     * Back button / gesture. While full screen is active Back never leaves full screen
     * (and never closes the tab or the app): it only steps back through the page history,
     * and does nothing when there is no history. Full screen ends only via the exit button.
     */
    private fun handleBack(allowExit: Boolean) {
        if (dismissSuggest()) return
        val t = current
        when {
            isFullScreen() -> {
                if (barHidden && !videoFullscreen && t != null && t.canBack) t.session.goBack()
                // otherwise: swallow the press, stay in full screen
            }
            findBar.visibility == View.VISIBLE -> closeFind()
            urlText.hasFocus() -> { urlText.clearFocus(); hideKeyboard() }
            t != null && t.canBack -> t.session.goBack()
            // A tab opened from a link closes on Back (like Chrome); other tabs are never closed by accident
            t != null && t.fromLink && tabs.size > 1 -> closeTab(t)
            allowExit -> {
                @Suppress("DEPRECATION")
                super.onBackPressed()
            }
        }
    }

    /** Android 13+ back gesture: keep a callback registered while in full screen so Back is always ours. */
    private fun setBackGuard(on: Boolean) {
        if (android.os.Build.VERSION.SDK_INT < 33) return
        val dispatcher = onBackInvokedDispatcher
        if (on && backGuard == null) {
            val cb = android.window.OnBackInvokedCallback { handleBack(allowExit = false) }
            dispatcher.registerOnBackInvokedCallback(android.window.OnBackInvokedDispatcher.PRIORITY_DEFAULT, cb)
            backGuard = cb
        } else if (!on && backGuard != null) {
            dispatcher.unregisterOnBackInvokedCallback(backGuard as android.window.OnBackInvokedCallback)
            backGuard = null
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && isFullScreen()) applyBarState() // re-hide system bars if they reappeared
    }

    private fun exitFullScreen() {
        if (videoFullscreen) current?.session?.exitFullScreen()
        videoFullscreen = false
        barHidden = false
        applyBarState()
    }

    private fun setupListeners() {
        urlText.setOnFocusChangeListener { _, hasFocus ->
            val t = current
            suppressSuggest = true
            if (hasFocus) {
                urlText.setText(if (t?.url == "about:blank") "" else (t?.url ?: ""))
                urlText.post { urlText.selectAll() }
            } else {
                dismissSuggest()
                if (t != null) urlText.setText(displayUrl(t))
            }
            suppressSuggest = false
            updateUi()
        }
        urlText.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(c: CharSequence?, a: Int, b: Int, d: Int) {}
            override fun onTextChanged(c: CharSequence?, a: Int, b: Int, d: Int) {}
            override fun afterTextChanged(e: android.text.Editable?) {
                if (!suppressSuggest) onUrlTextChanged(e?.toString() ?: "")
            }
        })
        urlText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) { go(); true } else false
        }
        // In the address bar: "X" clears the text while typing, or stops a loading page.
        reloadBtn.setOnClickListener {
            val t = current ?: return@setOnClickListener
            if (urlText.hasFocus()) urlText.setText("") else if (t.loading) t.session.stop()
        }
        findViewById<View>(R.id.homeBtn).setOnClickListener { goHome() }
        findViewById<View>(R.id.tabsBtn).setOnClickListener { showTabSwitcher() }
        menuBtn.setOnClickListener { showMenuPopup() }
        exitFullBtn.setOnClickListener { exitFullScreen() }

        // Find in page
        findInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString() ?: ""
                if (q.isEmpty()) current?.session?.finder?.clear()
                else current?.session?.finder?.find(q, 0)
            }
        })
        findViewById<View>(R.id.findNext).setOnClickListener {
            val q = findInput.text.toString()
            if (q.isNotEmpty()) current?.session?.finder?.find(q, 0)
        }
        findViewById<View>(R.id.findPrev).setOnClickListener {
            val q = findInput.text.toString()
            if (q.isNotEmpty()) current?.session?.finder?.find(q, 1) // 1 = search backwards
        }
        findViewById<View>(R.id.findClose).setOnClickListener { closeFind() }
    }

    // ------------------------------------------------------------------ Tabs

    private fun newSession(private: Boolean): GeckoSession =
        if (private) GeckoSession(GeckoSessionSettings.Builder().usePrivateMode(true).build())
        else GeckoSession()

    private fun openTab(url: String?, private: Boolean = false, select: Boolean = true, lazy: Boolean = false): Tab {
        val rt = runtime!!
        val tab = Tab(newSession(private), private)
        attach(tab)
        tab.session.open(rt)
        tabs.add(tab)
        if (url != null) {
            tab.url = url
            if (lazy) tab.pendingUrl = url
        }
        if (select) selectTab(tabs.size - 1)
        if (url != null && !lazy) tab.session.loadUri(url)
        updateUi()
        return tab
    }

    /** New tab: blank page with the address bar focused (like Chrome's new tab). */
    private fun openNewTab(private: Boolean = false) {
        openTab(null, private)
    }

    private fun focusAddressBar() {
        urlBar.visibility = View.VISIBLE
        urlText.requestFocus()
        handler.postDelayed({
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.showSoftInput(urlText, InputMethodManager.SHOW_IMPLICIT)
        }, 200)
    }

    private fun selectTab(index: Int) {
        if (index !in tabs.indices) return
        val prev = current
        currentIndex = index
        showCurrentSession()
        current?.let { t ->
            t.pendingUrl?.let { u -> t.pendingUrl = null; t.session.loadUri(u) }
        }
        // Let background tabs rest (saves battery and memory) unless audio is playing
        if (prev != null && prev !== current && !audioPlaying()) {
            try { prev.session.setActive(false) } catch (_: Exception) {}
        }
        videoFullscreen = false
        applyBarState()
        updateUi()
        // Safety net: make sure the engine view really shows the highlighted tab
        handler.postDelayed({ verifyDisplayedTab() }, 150)
    }

    /** Attaches the current tab's own session to the GeckoView (each tab keeps its own page). */
    private fun showCurrentSession() {
        val target = current?.session ?: return
        if (geckoView.session !== target) {
            if (geckoView.session != null) geckoView.releaseSession()
            geckoView.setSession(target)
        }
        target.setActive(true)
    }

    private fun verifyDisplayedTab() {
        val t = current ?: return
        if (geckoView.session !== t.session) showCurrentSession()
    }

    private fun closeTab(tab: Tab) {
        val idx = tabs.indexOf(tab)
        if (idx < 0) return
        val wasCurrent = idx == currentIndex
        tabs.removeAt(idx)
        if (tabs.isEmpty()) {
            geckoView.releaseSession()
            tab.session.close()
            currentIndex = -1
            openTab(store.homeUrl().ifBlank { null })
            return
        }
        if (wasCurrent) {
            geckoView.releaseSession()
            selectTab(minOf(idx, tabs.size - 1))
        } else if (idx < currentIndex) {
            currentIndex--
        }
        tab.session.close()
        updateUi()
    }

    private fun whenOpen(s: GeckoSession, tries: Int = 40, action: () -> Unit) {
        if (s.isOpen) action()
        else if (tries > 0) handler.postDelayed({ whenOpen(s, tries - 1, action) }, 50)
    }

    private fun attach(tab: Tab) {
        val s = tab.session

        s.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                tab.loading = true
                tab.progress = 5
                if (url.isNotEmpty()) tab.url = url
                refresh(tab)
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                tab.loading = false
                tab.progress = 100
                if (!tab.isPrivate && tab.url.startsWith("http")) {
                    val ht = tab.title
                    val hu = tab.url
                    ioSerial.execute { store.addHistory(ht, hu) }
                }
                refresh(tab)
            }

            override fun onProgressChange(session: GeckoSession, progress: Int) {
                val old = tab.progress
                tab.progress = progress
                if (progress == 100 || progress - old >= 8) refresh(tab)
            }
        }

        s.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                tab.canBack = canGoBack
                refresh(tab)
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                tab.canForward = canGoForward
                refresh(tab)
            }

            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                if (url != null) {
                    tab.url = url
                    refresh(tab)
                }
            }

            // Links that open in a new window (target=_blank, window.open)
            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
                val child = newSession(tab.isPrivate)
                val childTab = Tab(child, tab.isPrivate)
                childTab.url = uri
                childTab.fromLink = true
                attach(childTab)
                tabs.add(childTab)
                runOnUiThread {
                    whenOpen(child) { selectTab(tabs.indexOf(childTab)) }
                }
                return GeckoResult.fromValue(child)
            }
        }

        s.scrollDelegate = object : GeckoSession.ScrollDelegate {
            override fun onScrollChanged(session: GeckoSession, scrollX: Int, scrollY: Int) {
                tab.scrollY = scrollY
            }
        }

        s.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                tab.title = title ?: ""
                refresh(tab)
            }

            override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                if (tab === current) {
                    videoFullscreen = fullScreen
                    applyBarState()
                }
            }

            override fun onExternalResponse(session: GeckoSession, response: WebResponse) {
                runOnUiThread { startDownload(response) }
            }

            override fun onCloseRequest(session: GeckoSession) {
                runOnUiThread { closeTab(tab) }
            }
        }
    }

    // ------------------------------------------------------------------ UI state

    private fun refresh(tab: Tab) {
        if (tab === current) runOnUiThread { updateUi() }
    }

    private fun displayUrl(t: Tab): String {
        if (t.url.isEmpty() || t.url == "about:blank") return ""
        val host = try { Uri.parse(t.url).host?.removePrefix("www.") } catch (_: Exception) { null }
        return if (!host.isNullOrEmpty()) host else t.url
    }

    private fun updateUi() {
        val t = current ?: return
        if (!urlText.hasFocus()) urlText.setText(displayUrl(t))
        lockIcon.setImageResource(
            when {
                t.url.startsWith("https") -> R.drawable.ic_lock
                t.url.isEmpty() -> R.drawable.ic_search
                else -> R.drawable.ic_info
            }
        )
        val blank = t.url.isEmpty() || t.url == "about:blank"
        val editing = urlText.hasFocus() || blank
        engineBtn.visibility = if (editing) View.VISIBLE else View.GONE
        lockIcon.visibility = if (editing) View.GONE else View.VISIBLE
        if (editing) updateEngineIcon()
        urlBar.visibility = if (blank && !urlText.hasFocus()) View.INVISIBLE else View.VISIBLE
        if (blank != newTabShown) {
            newTabShown = blank
            newTab.visibility = if (blank) View.VISIBLE else View.GONE
            if (blank) renderShortcuts()
            applyHomeStyle(blank)
        }
        tabSidebar.visibility = if (blank || isFullScreen()) View.GONE else View.VISIBLE
        // "X" in the address bar: clear while typing, stop while loading, hidden otherwise
        reloadBtn.visibility = if (urlText.hasFocus() || t.loading) View.VISIBLE else View.GONE
        progress.visibility = if (t.loading) View.VISIBLE else View.INVISIBLE
        progress.progress = t.progress
        tabCount.text = if (tabs.size > 99) ":D" else tabs.size.toString()
        renderTabStrip()
    }

    // ------------------------------------------------------------------ Chrome-style tab strip

    private fun faviconHost(t: Tab): String? {
        if (t.isPrivate || !t.url.startsWith("http")) return null
        return try { Uri.parse(t.url).host } catch (_: Exception) { null }
    }

    private fun bindFavicon(iv: ImageView, t: Tab) {
        val host = faviconHost(t)
        if (host == null) {
            iv.setImageResource(if (t.isPrivate) R.drawable.ic_tabs else R.drawable.ic_globe)
            return
        }
        bindHost(iv, host)
    }

    /** Shows the website's logo (fetched once, cached in memory) in [iv]. */
    private fun bindHost(iv: ImageView, host: String) {
        val cached = favicons.get(host)
        if (cached != null) { iv.setImageBitmap(cached); return }
        iv.setImageResource(R.drawable.ic_globe)
        if (host in failedFavicons || !pendingFavicons.add(host)) return
        io.execute {
            var c: HttpURLConnection? = null
            try {
                c = URL("https://www.google.com/s2/favicons?domain=$host&sz=128")
                    .openConnection() as HttpURLConnection
                c.connectTimeout = 5000
                c.readTimeout = 5000
                val bmp = c.inputStream.use { BitmapFactory.decodeStream(it) }
                if (bmp != null) {
                    favicons.put(host, bmp)
                    runOnUiThread {
                        if (isDestroyed) return@runOnUiThread
                        lastStripSig = ""
                        renderTabStrip()
                        if (newTabShown) renderShortcuts()
                        updateEngineIcon()
                    }
                } else failedFavicons.add(host)
            } catch (_: Exception) {
                failedFavicons.add(host)
            } finally {
                c?.disconnect()
                pendingFavicons.remove(host)
            }
        }
    }

    // ------------------------------------------------------------------ Search engine selector

    private fun updateEngineIcon() {
        val name = store.engineName()
        bindHost(engineIcon, Store.engineHost(name))
        urlText.hint = "Search in $name"
        homePillIcon?.let { bindHost(it, Store.engineHost(name)) }
        homePillText?.text = "Search in $name"
    }

    private fun showEnginePopup(anchor: View = engineBtn) {
        lateinit var popup: PopupWindow
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        Store.ENGINES.keys.forEach { name ->
            val selected = name == store.engineName()
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(48)
                setPadding(dp(16), 0, dp(16), 0)
                setBackgroundResource(selectableBackground())
                setOnClickListener {
                    store.setEngine(name)
                    popup.dismiss()
                    updateEngineIcon()
                }
            }
            row.addView(ImageView(this).also { bindHost(it, Store.engineHost(name)) }.apply {
                layoutParams = LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginEnd = dp(14) }
            })
            row.addView(TextView(this).apply {
                text = name
                textSize = 15f
                setTextColor(getColor(if (selected) R.color.accent else R.color.text))
                if (selected) setTypeface(typeface, Typeface.BOLD)
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            if (selected) row.addView(TextView(this).apply {
                text = "\u2713"
                textSize = 16f
                setTextColor(getColor(R.color.accent))
            })
            list.addView(row)
        }
        val scroll = ScrollView(this)
        scroll.addView(list)
        popup = PopupWindow(scroll, dp(230), ViewGroup.LayoutParams.WRAP_CONTENT, true)
        popup.setBackgroundDrawable(getDrawable(R.drawable.bg_popup))
        popup.elevation = dp(10).toFloat()
        popup.isOutsideTouchable = true
        popup.height = minOf(dp(48) * Store.ENGINES.size + dp(12), (resources.displayMetrics.heightPixels * 0.6).toInt())
        popup.showAsDropDown(anchor, 0, dp(6))
    }

    // ------------------------------------------------------------------ Home shortcuts

    /** Dark teal gradient background + light icons while the Ice home page is showing. */
    private fun applyHomeStyle(home: Boolean) {
        if (home) rootFrame.setBackgroundResource(R.drawable.bg_home_gradient)
        else rootFrame.setBackgroundColor(getColor(R.color.surface))
        topBar.setBackgroundColor(if (home) Color.TRANSPARENT else getColor(R.color.surface))
        window.statusBarColor = if (home) Color.parseColor("#0C4D50") else prevStatusColor
        fun tint(v: View?) {
            when (v) {
                is ImageView -> if (home) v.setColorFilter(Color.WHITE) else v.clearColorFilter()
                is TextView -> v.setTextColor(if (home) Color.WHITE else getColor(R.color.icon))
                is ViewGroup -> for (i in 0 until v.childCount) tint(v.getChildAt(i))
            }
        }
        tint(findViewById<View>(R.id.homeBtn))
        tint(findViewById<View>(R.id.tabsBtn))
        tint(menuBtn)
        applySystemBars()
    }

    private fun renderShortcuts() {
        shortcutGrid.removeAllViews()
        shortcutGrid.gravity = Gravity.CENTER_HORIZONTAL
        val screenH = resources.displayMetrics.heightPixels

        // "Ice" wordmark
        shortcutGrid.addView(TextView(this).apply {
            text = "Ice"
            setTextColor(Color.WHITE)
            textSize = 50f
            typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
            letterSpacing = -0.02f
            gravity = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = (screenH * 0.07).toInt() }
        })

        // Search pill: [engine icon + arrow] Search in <engine>
        val pill = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundResource(R.drawable.bg_pill)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(50)
            ).apply { topMargin = dp(28); marginStart = dp(8); marginEnd = dp(8) }
            setOnClickListener {
                urlBar.visibility = View.VISIBLE
                focusAddressBar()
            }
        }
        val engineArea = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(6), 0)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
        }
        val icon = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(22), dp(22))
        }
        engineArea.addView(icon)
        engineArea.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_down)
            setColorFilter(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(dp(18), dp(18))
        })
        engineArea.setOnClickListener { showEnginePopup(engineArea) }
        val hint = TextView(this).apply {
            textSize = 15f
            maxLines = 1
            setTextColor(Color.parseColor("#B3FFFFFF"))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                .apply { marginStart = dp(6) }
        }
        pill.addView(engineArea)
        pill.addView(hint)
        shortcutGrid.addView(pill)
        homePillIcon = icon
        homePillText = hint
        updateEngineIcon()

        // Shortcuts card: 4 per row
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_shortcut_card)
            setPadding(dp(8), dp(14), dp(8), dp(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(22); marginStart = dp(8); marginEnd = dp(8) }
        }
        val tiles = mutableListOf<View>()
        store.shortcuts().forEach { e -> tiles.add(shortcutTile(e)) }
        tiles.add(addTile())
        tiles.chunked(4).forEach { chunk ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = 4f
            }
            chunk.forEach { row.addView(it) }
            repeat(4 - chunk.size) { row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f)) }
            card.addView(row)
        }
        shortcutGrid.addView(card)
    }

    private fun tile(label: String, add: Boolean = false, icon: (ImageView) -> Unit): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(2), dp(6), dp(2), dp(6))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val iconBox = FrameLayout(this).apply {
            setBackgroundResource(if (add) R.drawable.bg_tile_add else R.drawable.bg_tile_light)
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(48))
        }
        iconBox.addView(ImageView(this).also(icon).apply {
            if (add) setColorFilter(Color.WHITE)
            layoutParams = FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER)
        })
        box.addView(iconBox)
        box.addView(TextView(this).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 11f
            maxLines = 1
            gravity = Gravity.CENTER
            ellipsize = TextUtils.TruncateAt.END
            setPadding(0, dp(6), 0, 0)
        })
        return box
    }

    private fun shortcutTile(e: Entry): View {
        val host = try { Uri.parse(e.url).host } catch (_: Exception) { null }
        return tile(e.title) { iv ->
            if (host != null) bindHost(iv, host) else iv.setImageResource(R.drawable.ic_globe)
        }.apply {
            setOnClickListener { navigate(e.url) }
            setOnLongClickListener {
                AlertDialog.Builder(this@MainActivity)
                    .setTitle(e.title)
                    .setItems(arrayOf("Edit", "Remove")) { _, which ->
                        if (which == 0) showShortcutDialog(e)
                        else {
                            store.saveShortcuts(store.shortcuts().filter { it.url != e.url })
                            renderShortcuts()
                        }
                    }
                    .show()
                true
            }
        }
    }

    private fun addTile(): View =
        tile("", add = true) { it.setImageResource(R.drawable.ic_add) }.apply {
            setOnClickListener { showShortcutDialog(null) }
        }

    private fun showShortcutDialog(old: Entry?) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(8), dp(24), 0)
        }
        val name = EditText(this).apply {
            hint = "Name (optional)"
            setSingleLine()
            setText(old?.title ?: "")
        }
        val url = EditText(this).apply {
            hint = "https://example.com"
            setSingleLine()
            inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI
            setText(old?.url ?: "")
        }
        box.addView(name)
        box.addView(url)
        AlertDialog.Builder(this)
            .setTitle(if (old == null) "Add shortcut" else "Edit shortcut")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                var u = url.text.toString().trim()
                if (u.isEmpty()) { toast("Enter a website address"); return@setPositiveButton }
                if (!u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
                val host = try { Uri.parse(u).host?.removePrefix("www.") } catch (_: Exception) { null }
                val title = name.text.toString().trim().ifEmpty { host ?: u }
                val list = store.shortcuts().toMutableList()
                val i = if (old != null) list.indexOfFirst { it.url == old.url } else -1
                if (i >= 0) list[i] = Entry(title, u) else list.add(Entry(title, u))
                store.saveShortcuts(list)
                renderShortcuts()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun tabTitle(t: Tab) =
        if (t.title.isNotBlank()) t.title else displayUrl(t).ifEmpty { "New tab" }

    private fun renderTabStrip() {
        val sig = tabs.joinToString("|") {
            "${System.identityHashCode(it)}:${faviconHost(it)?.let { h -> favicons.get(h) != null }}:${it.isPrivate}"
        } + "#$currentIndex"
        if (sig == lastStripSig) return
        lastStripSig = sig

        // The stack starts in the upper part of the screen and grows downwards: first tab on top,
        // "+" after the last tab. Past the middle of the screen it scrolls.
        tabSidebarCol.removeAllViews()
        for (i in tabs.indices) {
            val t = tabs[i]
            val active = i == currentIndex
            tabSidebarCol.addView(makePill(active, topMargin = if (i == 0) 0 else 8).also { pill ->
                val icon = pill.getChildAt(0) as ImageView
                bindFavicon(icon, t)
                val host = faviconHost(t)
                icon.imageTintList =
                    if (host != null && favicons.get(host) != null) null
                    else ColorStateList.valueOf(if (active) RAIL_ICON_ACTIVE else Color.WHITE)
                pill.setOnClickListener { if (i != currentIndex) selectTab(i) }
                pill.setOnLongClickListener { showTabActions(t); true }
            })
        }
        tabSidebarCol.addView(makePill(false, topMargin = if (tabs.isEmpty()) 0 else 8).also { pill ->
            (pill.getChildAt(0) as ImageView).apply {
                setImageResource(R.drawable.ic_add)
                imageTintList = ColorStateList.valueOf(Color.WHITE)
            }
            pill.setOnClickListener { openNewTab() }
        })
        positionRail()
        if (currentIndex >= 0) {
            tabSidebar.post {
                val v = tabSidebarCol.getChildAt(currentIndex) ?: return@post
                tabSidebar.smoothScrollTo(0, maxOf(0, v.top - dp(60)))
            }
        }
    }

    /** One 40x40dp half-pill: flat left edge, 20dp radius on the right, no left border. */
    private fun makePill(active: Boolean, topMargin: Int): FrameLayout {
        val r = dp(20).toFloat()
        val radii = floatArrayOf(0f, 0f, r, r, r, r, 0f, 0f)
        val fill = GradientDrawable().apply {
            cornerRadii = radii
            setColor(if (active) RAIL_ACTIVE else RAIL_BG)
        }
        val border = GradientDrawable().apply {
            cornerRadii = radii
            setColor(Color.TRANSPARENT)
            setStroke(dp(1), RAIL_BORDER)
        }
        val bg = LayerDrawable(arrayOf(fill, border))
        // Push the border layer 2dp past the left edge so only top / right / bottom show
        bg.setLayerInset(1, -dp(2), 0, 0, 0)
        return FrameLayout(this).apply {
            background = bg
            layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { this.topMargin = dp(topMargin) }
            addView(ImageView(context).apply {
                // 20dp icon, nudged toward the rounded end
                layoutParams = FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER_VERTICAL or Gravity.END)
                    .apply { marginEnd = dp(8) }
            })
        }
    }

    // ------------------------------------------------------------------ Rail position

    /** Puts the stack 16dp below the address bar (or find bar) and keeps it above the lower half of the screen. */
    private fun positionRail() {
        val bottom = if (findBar.visibility == View.VISIBLE) findBar.bottom else topBar.bottom
        val top = bottom + dp(16)
        val limit = (rootFrame.height * RAIL_MAX_BOTTOM).toInt()
        val lp = tabSidebar.layoutParams as FrameLayout.LayoutParams
        if (lp.topMargin != top || lp.bottomMargin != 0) {
            lp.topMargin = top
            lp.bottomMargin = 0
            tabSidebar.layoutParams = lp
        }
        tabSidebar.maxHeightPx = maxOf(dp(96), limit - top)
    }

    private fun showTabActions(t: Tab) {
        val title = tabTitle(t)
        val names = if (tabs.size > 1) arrayOf("Close tab", "Close other tabs") else arrayOf("Close tab")
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(names) { _, which ->
                if (which == 0) closeTab(t)
                else tabs.toList().filter { it !== t }.forEach { closeTab(it) }
            }
            .show()
    }


    private fun applyBarState() {
        val hide = isFullScreen()
        tabSidebar.visibility = if (hide || newTabShown) View.GONE else View.VISIBLE
        topBar.visibility = if (hide) View.GONE else View.VISIBLE
        if (hide) findBar.visibility = View.GONE
        // The exit button is the only way out of full screen
        exitFullBtn.visibility = if (hide) View.VISIBLE else View.GONE
        exitFullBtn.setImageResource(R.drawable.ic_fullscreen_exit)
        exitFullBtn.bringToFront()
        setBackGuard(hide)
        applySystemBars()
    }

    /** Status/navigation bar icons follow the theme (dark icons on light bars) and hide in full screen. */
    @Suppress("DEPRECATION")
    private fun applySystemBars() {
        val hide = isFullScreen()
        val night = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val darkStatusIcons = !night && !newTabShown   // the home page has a dark teal status bar
        val darkNavIcons = !night
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            val c = window.insetsController ?: return
            val mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            var flags = 0
            if (darkStatusIcons) flags = flags or WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS
            if (darkNavIcons) flags = flags or WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            c.setSystemBarsAppearance(flags, mask)
            if (hide) {
                c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                c.hide(WindowInsets.Type.systemBars())
            } else {
                c.show(WindowInsets.Type.systemBars())
            }
        } else {
            var f = View.SYSTEM_UI_FLAG_VISIBLE
            if (hide) f = f or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            if (darkStatusIcons) f = f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            if (darkNavIcons && android.os.Build.VERSION.SDK_INT >= 26) f = f or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            window.decorView.systemUiVisibility = f
        }
    }

    // ------------------------------------------------------------------ Search suggestions

    private fun onUrlTextChanged(text: String) {
        suggestSeq++
        suggestJob?.let { handler.removeCallbacks(it) }
        val q = text.trim()
        if (!urlText.hasFocus() || q.isEmpty() || q.contains("://") || !store.suggestOn() ||
            current?.isPrivate == true) {
            dismissSuggest()
            return
        }
        val my = suggestSeq
        val job = Runnable {
            suggestIo.execute {
                if (my != suggestSeq) return@execute
                val list = fetchSuggestions(q)
                runOnUiThread { if (my == suggestSeq && urlText.hasFocus()) showSuggestions(list) }
            }
        }
        suggestJob = job
        handler.postDelayed(job, 180)
    }

    private fun fetchSuggestions(q: String): List<String> {
        var c: HttpURLConnection? = null
        return try {
            val url = store.suggestUrl().replace("%s", java.net.URLEncoder.encode(q, "UTF-8"))
            c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 3000
            c.readTimeout = 3000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Android 14; Mobile; rv:128.0) Gecko/128.0 Firefox/128.0")
            val text = c.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val arr = org.json.JSONArray(text).getJSONArray(1)
            (0 until minOf(arr.length(), 8)).mapNotNull { i ->
                val v = arr.opt(i)
                when (v) {
                    is String -> v
                    is org.json.JSONObject -> v.optString("phrase").ifEmpty { null }
                    else -> null
                }
            }
        } catch (_: Exception) {
            emptyList()
        } finally {
            c?.disconnect()
        }
    }

    private fun showSuggestions(list: List<String>) {
        if (list.isEmpty()) { dismissSuggest(); return }
        var box = suggestBox
        if (box == null) {
            box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(getColor(R.color.surface))
            }
            suggestBox = box
        }
        box.removeAllViews()
        list.forEach { sug ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(48)
                setPadding(dp(16), 0, dp(4), 0)
                setBackgroundResource(selectableBackground())
                setOnClickListener {
                    suppressSuggest = true
                    urlText.setText(sug)
                    suppressSuggest = false
                    go()
                }
            }
            row.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_search)
                layoutParams = LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginEnd = dp(16) }
            })
            row.addView(TextView(this).apply {
                text = sug
                textSize = 15f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(getColor(R.color.text))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            })
            // Arrow: copy the suggestion into the address bar for editing
            row.addView(ImageButton(this).apply {
                setImageResource(R.drawable.ic_north_west)
                setBackgroundResource(selectableBackground())
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
                setOnClickListener {
                    urlText.setText(sug)
                    urlText.setSelection(urlText.text.length)
                }
            })
            box.addView(row)
        }
        val existing = suggestPopup
        if (existing == null || !existing.isShowing) {
            val pw = PopupWindow(box, topBar.width, ViewGroup.LayoutParams.WRAP_CONTENT, false)
            pw.inputMethodMode = PopupWindow.INPUT_METHOD_NOT_NEEDED
            pw.isOutsideTouchable = false
            pw.elevation = dp(8).toFloat()
            suggestPopup = pw
            try { pw.showAsDropDown(topBar, 0, 0) } catch (_: Exception) {}
        } else {
            existing.update()
        }
    }

    /** @return true if a suggestion list was showing and has been closed */
    private fun dismissSuggest(): Boolean {
        suggestSeq++
        suggestJob?.let { handler.removeCallbacks(it) }
        val pw = suggestPopup
        val was = pw?.isShowing == true
        if (was) pw?.dismiss()
        suggestPopup = null
        suggestBox = null
        return was
    }

    private fun navigate(url: String) {
        current?.session?.loadUri(url)
    }

    private fun goHome() {
        val h = store.homeUrl()
        if (h.isBlank()) {
            // No home page set: show the shortcuts page
            val t = current ?: return
            t.url = ""; t.title = ""
            t.session.loadUri("about:blank")
            updateUi()
        } else navigate(h)
    }

    private fun go() {
        dismissSuggest()
        val text = urlText.text.toString().trim()
        if (text.isEmpty()) return
        val url = when {
            text.startsWith("http://") || text.startsWith("https://") -> text
            text.startsWith("about:") || text.startsWith("file://") -> text
            text.startsWith("localhost") || Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?(/.*)?$").matches(text) ->
                "http://$text"
            text.contains(" ") || !text.contains(".") -> store.searchUrl(text)
            else -> "https://$text"
        }
        navigate(url)
        hideKeyboard()
        urlText.clearFocus()
        geckoView.requestFocus()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(urlText.windowToken, 0)
        imm.hideSoftInputFromWindow(findInput.windowToken, 0)
    }

    // ------------------------------------------------------------------ Chrome-style menu

    private fun showMenuPopup() {
        val t = current ?: return
        val bookmarked = store.isBookmarked(t.url)
        lateinit var popup: PopupWindow

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }

        // Top icon row (Chrome order): Forward | Bookmark | Page info | Reload
        val iconRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            weightSum = 4f
        }
        fun iconButton(res: Int, enabled: Boolean, action: () -> Unit) {
            iconRow.addView(ImageButton(this).apply {
                setImageResource(res)
                setBackgroundResource(selectableBackground())
                alpha = if (enabled) 1f else 0.35f
                layoutParams = LinearLayout.LayoutParams(0, dp(48), 1f)
                setOnClickListener { if (enabled) { popup.dismiss(); action() } }
            })
        }
        iconButton(R.drawable.ic_forward, t.canForward) { t.session.goForward() }
        iconButton(if (bookmarked) R.drawable.ic_star else R.drawable.ic_star_border, true) {
            if (!t.url.startsWith("http")) toast("Nothing to bookmark yet")
            else if (bookmarked) { store.removeBookmark(t.url); toast("Bookmark removed") }
            else { store.addBookmark(t.title, t.url); toast("Bookmarked") }
        }
        iconButton(R.drawable.ic_info, true) { showPageInfo(t) }
        iconButton(R.drawable.ic_refresh, true) { t.session.reload() }
        root.addView(iconRow)
        root.addView(View(this).apply {
            setBackgroundColor(getColor(R.color.divider))
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
        })

        // Same order as Chrome's three-dot menu
        val items = listOf(
            Row("New tab", icon = R.drawable.ic_add) { openNewTab() },
            Row("New Incognito tab", icon = R.drawable.ic_tabs) { openNewTab(private = true) },
            Row("", divider = true),
            Row("History", icon = R.drawable.ic_history) { showHistory() },
            Row("Delete browsing data", icon = R.drawable.ic_trash) { confirmClearData() },
            Row("Downloads", icon = R.drawable.ic_download) { openDownloads() },
            Row("Bookmarks", icon = R.drawable.ic_star) { showBookmarks() },
            Row("", divider = true),
            Row("Share\u2026", icon = R.drawable.ic_share) { shareCurrent() },
            Row("Find in page", icon = R.drawable.ic_search) { openFind() },
            Row("Desktop site", icon = R.drawable.ic_desktop, checked = t.desktop) { toggleDesktop(t) },
            Row("Full screen", icon = R.drawable.ic_fullscreen) { barHidden = true; applyBarState() },
            Row("", divider = true),
            Row("Add-ons", icon = R.drawable.ic_extension) { showAddons() },
            Row("Settings", icon = R.drawable.ic_settings) { showSettings() }
        )
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        items.forEach {
            if (it.divider) list.addView(View(this).apply {
                setBackgroundColor(getColor(R.color.divider))
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1).apply {
                    topMargin = dp(4); bottomMargin = dp(4)
                }
            }) else list.addView(buildRow(it, { popup.dismiss() }, compact = true))
        }
        val scroll = ScrollView(this)
        scroll.addView(list)
        val maxH = (resources.displayMetrics.heightPixels * 0.72).toInt()
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        popup = PopupWindow(root, dp(264), ViewGroup.LayoutParams.WRAP_CONTENT, true)
        popup.setBackgroundDrawable(getDrawable(R.drawable.bg_popup))
        popup.elevation = dp(10).toFloat()
        popup.isOutsideTouchable = true
        root.measure(
            View.MeasureSpec.makeMeasureSpec(dp(264), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(maxH, View.MeasureSpec.AT_MOST)
        )
        if (root.measuredHeight > maxH) popup.height = maxH

        val loc = IntArray(2)
        menuBtn.getLocationOnScreen(loc)
        popup.showAtLocation(window.decorView, Gravity.TOP or Gravity.END, dp(8), loc[1] + dp(4))
    }

    // ------------------------------------------------------------------ Chrome-style tab switcher

    private fun showTabSwitcher() {
        val dialog = Dialog(this, R.style.FullDialog)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.background))
        }
        val titleView = TextView(this).apply {
            setTextColor(getColor(R.color.text))
            textSize = 20f
            setTypeface(typeface, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        header.addView(ImageButton(this).apply {
            setImageResource(R.drawable.ic_back)
            setBackgroundResource(selectableBackground())
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(56))
            setOnClickListener { dialog.dismiss() }
        })
        header.addView(titleView)
        header.addView(ImageButton(this).apply {
            setImageResource(R.drawable.ic_add)
            setBackgroundResource(selectableBackground())
            layoutParams = LinearLayout.LayoutParams(dp(48), dp(56))
            setOnClickListener { dialog.dismiss(); openNewTab() }
        })
        root.addView(header, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(56)))

        val grid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), dp(4), dp(8), dp(16))
        }
        val scroll = ScrollView(this)
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        fun render() {
            titleView.text = if (tabs.size == 1) "1 tab" else "${tabs.size} tabs"
            grid.removeAllViews()
            tabs.chunked(2).forEach { chunk ->
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    weightSum = 2f
                }
                chunk.forEach { t ->
                    row.addView(buildTabCard(t, dialog) { render() })
                }
                if (chunk.size == 1) {
                    row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
                }
                grid.addView(row)
            }
        }
        render()

        dialog.setContentView(root)
        dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        dialog.show()
    }

    private fun buildTabCard(t: Tab, dialog: Dialog, onChanged: () -> Unit): View {
        val selected = t === current
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(if (selected) R.drawable.bg_card_selected else R.drawable.bg_card)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(6), dp(6), dp(6), dp(6))
            }
            setOnClickListener { dialog.dismiss(); selectTab(tabs.indexOf(t)) }
        }
        val title = if (t.title.isNotBlank()) t.title else displayUrl(t).ifEmpty { "New tab" }

        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(4), dp(2), dp(4))
        }
        head.addView(ImageView(this).also { bindFavicon(it, t) }.apply {
            layoutParams = LinearLayout.LayoutParams(dp(16), dp(16)).apply { marginEnd = dp(8) }
        })
        head.addView(TextView(this).apply {
            text = title
            setTextColor(getColor(R.color.text))
            textSize = 13f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        head.addView(ImageButton(this).apply {
            setImageResource(R.drawable.ic_close)
            setBackgroundResource(selectableBackground())
            setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(36))
            setOnClickListener {
                closeTab(t)
                onChanged() // closing the last tab opens a fresh one, so the grid always refreshes
            }
        })
        card.addView(head)

        // Preview area (a coloured block with the site initial / incognito label)
        val preview = TextView(this).apply {
            text = if (t.isPrivate) "Incognito" else displayUrl(t).ifEmpty { "New tab" }
            setTextColor(getColor(R.color.text_secondary))
            textSize = 15f
            gravity = Gravity.CENTER
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setBackgroundColor(getColor(R.color.urlbar))
            setPadding(dp(8), dp(8), dp(8), dp(8))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(130)).apply {
                setMargins(dp(6), 0, dp(6), dp(8))
            }
        }
        card.addView(preview)
        return card
    }

    // ------------------------------------------------------------------ Sheets & dialogs

    private fun showBookmarks() {
        val rows = store.bookmarks().map { e ->
            Row(e.title, subtitle = e.url, icon = R.drawable.ic_star,
                trailingIcon = R.drawable.ic_trash,
                onTrailing = { store.removeBookmark(e.url); showBookmarks() },
                onClick = { navigate(e.url) })
        }
        showSheet("Bookmarks", rows, "No bookmarks yet. Open the menu and tap the star.")
    }

    private fun showHistory() {
        val rows = mutableListOf<Row>()
        val items = store.history()
        if (items.isNotEmpty()) {
            rows.add(Row("Clear history", icon = R.drawable.ic_trash) {
                store.clearHistory(); toast("History cleared")
            })
        }
        items.forEach { e ->
            rows.add(Row(e.title, subtitle = e.url, icon = R.drawable.ic_history) { navigate(e.url) })
        }
        showSheet("History", rows, "No history yet.")
    }

    private fun showSettings() {
        showSheet("Settings", listOf(
            Row("Home page", subtitle = store.homeUrl().ifBlank { "Not set" }, icon = R.drawable.ic_home) {
                showHomeDialog()
            },
            Row("Search engine", subtitle = store.engineName(), icon = R.drawable.ic_search) {
                showEnginePicker()
            },
            Row("Search suggestions: " + if (store.suggestOn()) "On" else "Off",
                subtitle = "Sends what you type to the selected search engine",
                icon = R.drawable.ic_search) {
                store.setSuggestOn(!store.suggestOn())
                toast("Search suggestions " + if (store.suggestOn()) "on" else "off")
            },
            Row("About Ice", subtitle = "Version 1.0", icon = R.drawable.ic_info) {
                AlertDialog.Builder(this)
                    .setTitle("Ice")
                    .setMessage("Ice 1.0\nA fast, private browser built on the Firefox (Gecko) engine, with a built-in ad blocker.")
                    .setPositiveButton("OK", null)
                    .show()
            },
            Row("Background play: " + if (store.bgPlay()) "On" else "Off",
                subtitle = "Keep playing audio/video when the app is minimised",
                icon = R.drawable.ic_history) {
                store.setBgPlay(!store.bgPlay())
                toast("Background play " + if (store.bgPlay()) "on" else "off")
            },
            Row("Clear cookies, cache and site data", subtitle = "Signs you out of websites",
                icon = R.drawable.ic_trash) { confirmClearData() }
        ))
    }

    private fun showHomeDialog() {
        val input = EditText(this).apply {
            setText(store.homeUrl())
            hint = "https://example.com"
            setSingleLine()
            setSelectAllOnFocus(true)
        }
        AlertDialog.Builder(this)
            .setTitle("Home page")
            .setMessage("The Home button opens this address.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                var u = input.text.toString().trim()
                if (u.isNotEmpty() && !u.startsWith("http://") && !u.startsWith("https://")) u = "https://$u"
                store.setHomeUrl(u)
                toast(if (u.isEmpty()) "Home page cleared" else "Home page saved")
            }
            .setNeutralButton("Use current page") { _, _ ->
                val u = current?.url ?: ""
                if (u.startsWith("http")) { store.setHomeUrl(u); toast("Home page saved") }
                else toast("Open a page first")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showEnginePicker() {
        showSheet("Search engine", Store.ENGINES.keys.map { name ->
            Row(name, subtitle = if (name == store.engineName()) "Selected" else null,
                icon = R.drawable.ic_search) {
                store.setEngine(name); toast("Search engine: $name")
            }
        })
    }

    private fun confirmClearData() {
        AlertDialog.Builder(this)
            .setTitle("Clear browsing data?")
            .setMessage("This removes cookies, cache and site data. You will be signed out of websites such as Google.")
            .setPositiveButton("Clear") { _, _ ->
                runtime?.storageController?.clearData(StorageController.ClearFlags.ALL)?.onDone(
                    { store.clearHistory(); toast("Browsing data cleared") },
                    { toast("Could not clear data: ${it.message}") }
                )
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toggleDesktop(t: Tab) {
        t.desktop = !t.desktop
        val st = t.session.settings
        st.setUserAgentMode(
            if (t.desktop) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
            else GeckoSessionSettings.USER_AGENT_MODE_MOBILE
        )
        st.setViewportMode(
            if (t.desktop) GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
            else GeckoSessionSettings.VIEWPORT_MODE_MOBILE
        )
        t.session.reload()
        toast(if (t.desktop) "Desktop site on" else "Desktop site off")
    }

    private fun shareCurrent() {
        val t = current ?: return
        if (!t.url.startsWith("http")) { toast("Nothing to share yet"); return }
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, t.url)
            putExtra(Intent.EXTRA_SUBJECT, t.title)
        }
        startActivity(Intent.createChooser(i, "Share link"))
    }

    private fun openDownloads() {
        try {
            startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {
            toast("No Downloads app found")
        }
    }

    private fun startDownload(response: WebResponse) {
        try {
            fun header(n: String) = response.headers.entries.firstOrNull { it.key.equals(n, true) }?.value
            val mime = header("content-type")?.substringBefore(';')?.trim()
            val name = URLUtil.guessFileName(response.uri, header("content-disposition"), mime)
            val req = DownloadManager.Request(Uri.parse(response.uri))
                .setTitle(name)
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            if (mime != null) req.setMimeType(mime)
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            } else {
                req.setDestinationInExternalFilesDir(this, Environment.DIRECTORY_DOWNLOADS, name)
            }
            (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(req)
            toast("Downloading $name")
        } catch (e: Exception) {
            toast("Download failed: ${e.message}")
        } finally {
            try { response.body?.close() } catch (_: Exception) {}
        }
    }

    private fun showPageInfo(t: Tab) {
        val secure = t.url.startsWith("https")
        AlertDialog.Builder(this)
            .setTitle(if (t.url.isEmpty()) "New tab" else if (secure) "Connection is secure" else "Connection is not secure")
            .setMessage(t.url.ifEmpty { "No page loaded" })
            .setPositiveButton("OK", null)
            .show()
    }

    private fun openFind() {
        findBar.visibility = View.VISIBLE
        findBar.post { positionRail() }
        findInput.requestFocus()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(findInput, 0)
    }

    private fun closeFind() {
        current?.session?.finder?.clear()
        findInput.setText("")
        findBar.visibility = View.GONE
        hideKeyboard()
    }

    // ------------------------------------------------------------------ Add-ons

    private fun setupExtensions(rt: GeckoRuntime) {
        val controller = rt.webExtensionController
        controller.setPromptDelegate(buildPromptDelegate())
        // Built-in YouTube ad blocker (uBlock Origin)
        controller.ensureBuiltIn(UBLOCK_URI, UBLOCK_ID).onDone(
            { ext -> if (ext != null) controller.setAllowedInPrivateBrowsing(ext, true) }, // block ads in Incognito too
            { toast("Could not load uBlock Origin: ${it.message}") }
        )
    }

    private fun showAddons() {
        val controller = runtime?.webExtensionController ?: return
        controller.list().onDone(
            { list ->
                val addons = list ?: emptyList()
                val rows = mutableListOf<Row>()
                rows.add(Row("Add extension", subtitle = "Popular picks or an .xpi link",
                    icon = R.drawable.ic_add) { showAddMenu() })
                addons.forEach { ext ->
                    val name = ext.metaData?.name ?: ext.id
                    val builtIn = ext.id == UBLOCK_ID
                    rows.add(Row(
                        title = name,
                        subtitle = (if (builtIn) "Built-in ad blocker" else "Version ${ext.metaData?.version ?: "?"}"),
                        icon = R.drawable.ic_extension,
                        trailingIcon = if (builtIn) null else R.drawable.ic_trash,
                        onTrailing = if (builtIn) null else ({ confirmRemove(ext) }),
                        onClick = { }
                    ))
                }
                runOnUiThread { showSheet("Add-ons (${addons.size})", rows) }
            },
            { toast("Could not list add-ons: ${it.message}") }
        )
    }

    private fun confirmRemove(ext: WebExtension) {
        val name = ext.metaData?.name ?: ext.id
        AlertDialog.Builder(this)
            .setTitle("Remove $name?")
            .setPositiveButton("Remove") { _, _ ->
                runtime?.webExtensionController?.uninstall(ext)?.onDone(
                    { toast("Removed: $name"); showAddons() },
                    { toast("Remove failed: ${it.message}") }
                )
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAddMenu() {
        val rows = mutableListOf<Row>()
        POPULAR.forEach { (name, link) ->
            rows.add(Row(name, icon = R.drawable.ic_extension) { installExtension(link) })
        }
        rows.add(Row("Custom .xpi link...", icon = R.drawable.ic_add) { showCustomInstallDialog() })
        showSheet("Add an extension", rows)
    }

    private fun showCustomInstallDialog() {
        val input = EditText(this).apply {
            hint = "https://.../extension.xpi"
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("Install Firefox extension")
            .setMessage("Paste a direct .xpi link (on addons.mozilla.org: long-press \"Add to Firefox\" and copy the link).")
            .setView(input)
            .setPositiveButton("Install") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isNotEmpty()) installExtension(url)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun installExtension(url: String) {
        toast("Installing...")
        runtime?.webExtensionController?.install(url)?.onDone(
            { ext ->
                toast("Installed: ${ext?.metaData?.name ?: "extension"}")
            },
            { toast("Install failed: ${it.message}") }
        )
    }

    /**
     * PromptDelegate that approves extension install prompts. Built as a dynamic proxy so it
     * compiles against any GeckoView version (prompt method signatures differ between releases).
     */
    private fun buildPromptDelegate(): WebExtensionController.PromptDelegate {
        val handler = InvocationHandler { proxy, method, args ->
            when (method.name) {
                "hashCode" -> System.identityHashCode(proxy)
                "equals" -> proxy === args?.get(0)
                "toString" -> "ExtensionPromptDelegate"
                else -> {
                    if (method.returnType == GeckoResult::class.java) {
                        val argType = (method.genericReturnType as? ParameterizedType)
                            ?.actualTypeArguments?.firstOrNull() as? Class<*>
                        when {
                            argType == AllowOrDeny::class.java ->
                                GeckoResult.fromValue(AllowOrDeny.ALLOW)
                            argType != null && argType.simpleName == "PermissionPromptResponse" -> {
                                val ctor = argType.constructors.first()
                                val values = ctor.parameterTypes.indices.map { it != 1 }
                                GeckoResult.fromValue(ctor.newInstance(*values.toTypedArray()))
                            }
                            else -> null
                        }
                    } else null
                }
            }
        }
        return Proxy.newProxyInstance(
            WebExtensionController.PromptDelegate::class.java.classLoader,
            arrayOf(WebExtensionController.PromptDelegate::class.java),
            handler
        ) as WebExtensionController.PromptDelegate
    }

    // ------------------------------------------------------------------ Bottom sheet

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun selectableBackground(): Int {
        val out = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, out, true)
        return out.resourceId
    }

    private fun showSheet(title: String, rows: List<Row>, emptyText: String? = null) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_sheet)
            setPadding(0, dp(10), 0, dp(12))
        }
        root.addView(View(this).apply {
            setBackgroundResource(R.drawable.bg_handle)
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(4)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(10)
            }
        })
        root.addView(TextView(this).apply {
            text = title
            setTextColor(getColor(R.color.text))
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(20), dp(4), dp(20), dp(8))
        })

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (rows.isEmpty() && emptyText != null) {
            list.addView(TextView(this).apply {
                text = emptyText
                setTextColor(getColor(R.color.text_secondary))
                textSize = 14f
                setPadding(dp(20), dp(12), dp(20), dp(20))
            })
        }
        rows.forEach { row -> list.addView(buildRow(row, { dialog.dismiss() })) }

        val scroll = ScrollView(this)
        scroll.addView(list)
        val maxH = (resources.displayMetrics.heightPixels * 0.62).toInt()
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            if (rows.size > 6) maxH else ViewGroup.LayoutParams.WRAP_CONTENT
        )
        root.addView(scroll, lp)

        dialog.setContentView(root)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
            setDimAmount(0.45f)
        }
        dialog.show()
    }

    private fun buildRow(row: Row, dismiss: () -> Unit, compact: Boolean = false): View {
        val vPad = if (compact) dp(10) else dp(11)
        val line = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), vPad, dp(12), vPad)
            if (compact) minimumHeight = dp(48)
            setBackgroundResource(selectableBackground())
            setOnClickListener { dismiss(); row.onClick() }
        }
        if (row.icon != null) {
            line.addView(ImageView(this).apply {
                setImageResource(row.icon)
                layoutParams = LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(16) }
            })
        }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        texts.addView(TextView(this).apply {
            text = row.title
            setTextColor(getColor(R.color.text))
            textSize = 16f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        if (!row.subtitle.isNullOrEmpty()) {
            texts.addView(TextView(this).apply {
                text = row.subtitle
                setTextColor(getColor(R.color.text_secondary))
                textSize = 12f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
        }
        line.addView(texts)
        if (row.checked != null) {
            line.addView(CheckBox(this).apply {
                isChecked = row.checked
                isClickable = false
                isFocusable = false
                buttonTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.accent))
            })
        }
        if (row.trailingIcon != null && row.onTrailing != null) {
            line.addView(ImageView(this).apply {
                setImageResource(row.trailingIcon)
                setPadding(dp(10), dp(10), dp(10), dp(10))
                setBackgroundResource(selectableBackground())
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
                setOnClickListener { dismiss(); row.onTrailing.invoke() }
            })
        }
        return line
    }

    // ------------------------------------------------------------------ Helpers

    private fun <T> GeckoResult<T>.onDone(ok: (T?) -> Unit, err: (Throwable) -> Unit) {
        this.then(
            GeckoResult.OnValueListener<T, Void> { ok(it); null },
            GeckoResult.OnExceptionListener<Void> { err(it); null }
        )
    }

    private fun toast(msg: String) =
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
}
