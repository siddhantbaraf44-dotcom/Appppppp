package com.example.minibrowser

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import java.lang.reflect.InvocationHandler
import java.lang.reflect.ParameterizedType
import java.lang.reflect.Proxy
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController

class MainActivity : Activity() {

    companion object {
        private var runtime: GeckoRuntime? = null
        private const val HOME = "https://m.youtube.com"
        private const val PREFS = "minibrowser"
        private const val KEY_LAST_URL = "last_url"

        // uBlock Origin is unpacked into assets/extensions/ublock by the GitHub Action
        private const val UBLOCK_URI = "resource://android/assets/extensions/ublock/"
        private const val UBLOCK_ID = "uBlock0@raymondhill.net"

        // Quick-install list: name to .xpi link on addons.mozilla.org
        private val POPULAR = listOf(
            "SponsorBlock (skip sponsor segments)" to "https://addons.mozilla.org/firefox/downloads/latest/sponsorblock/latest.xpi",
            "Return YouTube Dislike" to "https://addons.mozilla.org/firefox/downloads/latest/return-youtube-dislikes/latest.xpi",
            "Enhancer for YouTube" to "https://addons.mozilla.org/firefox/downloads/latest/enhancer-for-youtube/latest.xpi",
            "Dark Reader" to "https://addons.mozilla.org/firefox/downloads/latest/darkreader/latest.xpi"
        )
    }

    private lateinit var geckoView: GeckoView
    private lateinit var session: GeckoSession
    private lateinit var urlBar: EditText
    private lateinit var toolbar: View
    private lateinit var exitFullBtn: Button
    private var canGoBack = false
    private var barHidden = false      // user pressed the full-screen button
    private var videoFullscreen = false // page (YouTube video) went full screen

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        geckoView = findViewById(R.id.geckoview)
        urlBar = findViewById(R.id.urlBar)
        toolbar = findViewById(R.id.toolbar)
        exitFullBtn = findViewById(R.id.exitFullBtn)

        // The Gecko profile (cookies, logins, site storage) is kept on disk by default,
        // so a Google sign-in stays saved between app launches.
        val rt = runtime ?: GeckoRuntime.create(applicationContext).also { runtime = it }
        setupExtensions(rt)

        session = GeckoSession()
        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                this@MainActivity.canGoBack = canGoBack
            }

            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                if (url != null) {
                    if (!urlBar.hasFocus()) urlBar.setText(url)
                    getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                        .edit().putString(KEY_LAST_URL, url).apply()
                }
            }
        }
        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                videoFullscreen = fullScreen
                applyBarState()
            }
        }
        session.open(rt)
        geckoView.setSession(session)

        val last = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_LAST_URL, null)
        session.loadUri(last ?: HOME)

        urlBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) { go(); true } else false
        }
        findViewById<Button>(R.id.homeBtn).setOnClickListener { session.loadUri(HOME) }
        findViewById<Button>(R.id.addonBtn).setOnClickListener { showInstalledAddons() }
        findViewById<Button>(R.id.fullBtn).setOnClickListener { barHidden = true; applyBarState() }
        exitFullBtn.setOnClickListener { barHidden = false; applyBarState() }
    }

    /** Shows/hides the search bar and system bars depending on the current mode. */
    private fun applyBarState() {
        val hide = barHidden || videoFullscreen
        toolbar.visibility = if (hide) View.GONE else View.VISIBLE
        exitFullBtn.visibility = if (barHidden && !videoFullscreen) View.VISIBLE else View.GONE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            if (hide) (View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
            else View.SYSTEM_UI_FLAG_VISIBLE
    }

    // ---------------------------------------------------------------- Extensions

    private fun setupExtensions(rt: GeckoRuntime) {
        val controller = rt.webExtensionController

        // Allows installing extensions from an .xpi URL.
        controller.setPromptDelegate(buildPromptDelegate())

        // Built-in YouTube ad blocker (uBlock Origin)
        controller.ensureBuiltIn(UBLOCK_URI, UBLOCK_ID).onDone(
            { toast("uBlock Origin active") },
            { toast("Could not load uBlock Origin: ${it.message}") }
        )
    }

    /** Add-ons screen: lists installed add-ons; tap one to remove it. */
    private fun showInstalledAddons() {
        val controller = runtime?.webExtensionController ?: return
        controller.list().onDone(
            { list ->
                val addons = list ?: emptyList()
                val labels = addons.map {
                    val name = it.metaData?.name ?: it.id
                    if (it.id == UBLOCK_ID) "$name (built-in)" else name
                }.toTypedArray()

                runOnUiThread {
                    val b = AlertDialog.Builder(this)
                        .setTitle("Add-ons (${addons.size})")
                        .setPositiveButton("Add new") { _, _ -> showAddMenu() }
                        .setNegativeButton("Close", null)
                    if (labels.isEmpty()) b.setMessage("No add-ons installed.")
                    else b.setItems(labels) { _, which -> showAddonOptions(addons[which]) }
                    b.show()
                }
            },
            { toast("Could not list add-ons: ${it.message}") }
        )
    }

    private fun showAddonOptions(ext: WebExtension) {
        val name = ext.metaData?.name ?: ext.id
        if (ext.id == UBLOCK_ID) {
            AlertDialog.Builder(this)
                .setTitle(name)
                .setMessage("This is the built-in ad blocker and can't be removed.")
                .setPositiveButton("OK", null)
                .show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle(name)
            .setMessage("Version: ${ext.metaData?.version ?: "?"}")
            .setPositiveButton("Remove") { _, _ -> removeExtension(ext) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun removeExtension(ext: WebExtension) {
        val name = ext.metaData?.name ?: ext.id
        runtime?.webExtensionController?.uninstall(ext)?.onDone(
            { toast("Removed: $name") },
            { toast("Remove failed: ${it.message}") }
        )
    }

    /** Add-on install menu: popular list or custom .xpi link. */
    private fun showAddMenu() {
        val labels = (POPULAR.map { it.first } + "Custom .xpi link...").toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Add an extension")
            .setItems(labels) { _, which ->
                if (which < POPULAR.size) installExtension(POPULAR[which].second)
                else showCustomInstallDialog()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showCustomInstallDialog() {
        val input = EditText(this).apply {
            hint = "https://.../extension.xpi"
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("Install Firefox extension")
            .setMessage("Paste a direct .xpi link (on addons.mozilla.org: long-press \"Add to Firefox\" > copy link).")
            .setView(input)
            .setPositiveButton("Install") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isNotEmpty()) installExtension(url)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun installExtension(url: String) {
        toast("Installing...")
        runtime?.webExtensionController?.install(url)?.onDone(
            { toast("Installed: ${it?.metaData?.name ?: "extension"}") },
            { toast("Install failed: ${it.message}") }
        )
    }

    /**
     * Builds a PromptDelegate that approves extension install/permission prompts.
     * Uses a dynamic proxy so it compiles against any GeckoView version
     * (the prompt method signatures differ between releases).
     */
    private fun buildPromptDelegate(): WebExtensionController.PromptDelegate {
        val handler = InvocationHandler { proxy, method, args ->
            when (method.name) {
                "hashCode" -> System.identityHashCode(proxy)
                "equals" -> proxy === args?.get(0)
                "toString" -> "ExtensionPromptDelegate"
                else -> {
                    if (method.returnType == GeckoResult::class.java) {
                        val argType = (method.genericReturnType as? ParameterizedType)
                            ?.actualTypeArguments?.firstOrNull() as? Class<*>
                        when {
                            argType == AllowOrDeny::class.java ->
                                GeckoResult.fromValue(AllowOrDeny.ALLOW)
                            argType != null && argType.simpleName == "PermissionPromptResponse" -> {
                                val ctor = argType.constructors.first()
                                // booleans: [permissions granted = true, private mode = false, rest = true]
                                val values = ctor.parameterTypes.indices.map { it != 1 }
                                GeckoResult.fromValue(ctor.newInstance(*values.toTypedArray()))
                            }
                            else -> null
                        }
                    } else null
                }
            }
        }
        return Proxy.newProxyInstance(
            WebExtensionController.PromptDelegate::class.java.classLoader,
            arrayOf(WebExtensionController.PromptDelegate::class.java),
            handler
        ) as WebExtensionController.PromptDelegate
    }

    // ---------------------------------------------------------------- Helpers

    private fun <T> GeckoResult<T>.onDone(ok: (T?) -> Unit, err: (Throwable) -> Unit) {
        this.then(
            GeckoResult.OnValueListener<T, Void> { ok(it); null },
            GeckoResult.OnExceptionListener<Void> { err(it); null }
        )
    }

    private fun go() {
        val text = urlBar.text.toString().trim()
        if (text.isEmpty()) return
        val url = when {
            text.startsWith("http://") || text.startsWith("https://") -> text
            text.contains(" ") || !text.contains(".") ->
                "https://duckduckgo.com/?q=" + java.net.URLEncoder.encode(text, "UTF-8")
            else -> "https://$text"
        }
        session.loadUri(url)
        urlBar.clearFocus()
        geckoView.requestFocus()
    }

    private fun toast(msg: String) =
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            barHidden && !videoFullscreen -> { barHidden = false; applyBarState() }
            canGoBack -> session.goBack()
            else -> super.onBackPressed()
        }
    }
}
