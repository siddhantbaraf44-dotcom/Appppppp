package com.example.minibrowser

import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.lang.reflect.InvocationHandler
import java.lang.reflect.ParameterizedType
import java.lang.reflect.Proxy
import org.mozilla.geckoview.AllowOrDeny
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoSessionSettings
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.StorageController
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController

/** One browser tab = one GeckoSession plus the state the UI needs. */
class Tab(val session: GeckoSession, val isPrivate: Boolean) {
    var title = ""
    var url = ""
    var progress = 0
    var loading = false
    var canBack = false
    var canForward = false
    var desktop = false
}

/** A row in the bottom sheet. */
data class Row(
    val title: String,
    val subtitle: String? = null,
    val icon: Int? = null,
    val trailingIcon: Int? = null,
    val onTrailing: (() -> Unit)? = null,
    val onClick: () -> Unit
)

class MainActivity : Activity() {

    companion object {
        private var runtime: GeckoRuntime? = null
        private const val HOME = "https://m.youtube.com"

        // uBlock Origin is unpacked into assets/extensions/ublock by the GitHub Action
        private const val UBLOCK_URI = "resource://android/assets/extensions/ublock/"
        private const val UBLOCK_ID = "uBlock0@raymondhill.net"

        private val POPULAR = listOf(
            "SponsorBlock" to "https://addons.mozilla.org/firefox/downloads/latest/sponsorblock/latest.xpi",
            "Return YouTube Dislike" to "https://addons.mozilla.org/firefox/downloads/latest/return-youtube-dislikes/latest.xpi",
            "Enhancer for YouTube" to "https://addons.mozilla.org/firefox/downloads/latest/enhancer-for-youtube/latest.xpi",
            "Dark Reader" to "https://addons.mozilla.org/firefox/downloads/latest/darkreader/latest.xpi"
        )
    }

    private val tabs = mutableListOf<Tab>()
    private var currentIndex = -1
    private val current: Tab? get() = tabs.getOrNull(currentIndex)

    private lateinit var store: Store
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var geckoView: GeckoView
    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var findBar: View
    private lateinit var urlText: EditText
    private lateinit var findInput: EditText
    private lateinit var lockIcon: ImageView
    private lateinit var reloadBtn: ImageButton
    private lateinit var backBtn: ImageButton
    private lateinit var forwardBtn: ImageButton
    private lateinit var progress: ProgressBar
    private lateinit var tabCount: TextView
    private lateinit var exitFullBtn: ImageButton

    private var barHidden = false       // user pressed "Full screen"
    private var videoFullscreen = false // a page/video went full screen

    // ------------------------------------------------------------------ Lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        store = Store(this)

        geckoView = findViewById(R.id.geckoview)
        topBar = findViewById(R.id.topBar)
        bottomBar = findViewById(R.id.bottomBar)
        findBar = findViewById(R.id.findBar)
        urlText = findViewById(R.id.urlText)
        findInput = findViewById(R.id.findInput)
        lockIcon = findViewById(R.id.lockIcon)
        reloadBtn = findViewById(R.id.reloadBtn)
        backBtn = findViewById(R.id.backBtn)
        forwardBtn = findViewById(R.id.forwardBtn)
        progress = findViewById(R.id.progress)
        tabCount = findViewById(R.id.tabCount)
        exitFullBtn = findViewById(R.id.exitFullBtn)

        // The Gecko profile (cookies, logins, site storage) is kept on disk, so a
        // Google sign-in stays saved between launches. Private tabs are not saved.
        val rt = runtime ?: GeckoRuntime.create(applicationContext).also { runtime = it }
        setupExtensions(rt)
        setupListeners()

        openTab(intent?.dataString ?: store.lastUrl() ?: HOME)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        intent?.dataString?.let { openTab(it) }
    }

    override fun onDestroy() {
        tabs.forEach { try { it.session.close() } catch (_: Exception) {} }
        tabs.clear()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        val t = current
        when {
            findBar.visibility == View.VISIBLE -> closeFind()
            barHidden && !videoFullscreen -> { barHidden = false; applyBarState() }
            t != null && t.canBack -> t.session.goBack()
            tabs.size > 1 && t != null -> closeTab(t)
            else -> super.onBackPressed()
        }
    }

    private fun setupListeners() {
        urlText.setOnFocusChangeListener { _, hasFocus ->
            val t = current
            if (hasFocus) {
                urlText.setText(t?.url ?: "")
                urlText.post { urlText.selectAll() }
            } else if (t != null) {
                urlText.setText(displayUrl(t))
            }
        }
        urlText.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) { go(); true } else false
        }
        reloadBtn.setOnClickListener {
            val t = current ?: return@setOnClickListener
            if (t.loading) t.session.stop() else t.session.reload()
        }
        backBtn.setOnClickListener { current?.let { if (it.canBack) it.session.goBack() } }
        forwardBtn.setOnClickListener { current?.let { if (it.canForward) it.session.goForward() } }
        findViewById<View>(R.id.homeBtn).setOnClickListener { current?.session?.loadUri(HOME) }
        findViewById<View>(R.id.tabsBtn).setOnClickListener { showTabs() }
        findViewById<View>(R.id.menuBtn).setOnClickListener { showMenu() }
        exitFullBtn.setOnClickListener { barHidden = false; applyBarState() }

        // Find in page
        findInput.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString() ?: ""
                if (q.isEmpty()) current?.session?.finder?.clear()
                else current?.session?.finder?.find(q, 0)
            }
        })
        findViewById<View>(R.id.findNext).setOnClickListener {
            val q = findInput.text.toString()
            if (q.isNotEmpty()) current?.session?.finder?.find(q, 0)
        }
        findViewById<View>(R.id.findPrev).setOnClickListener {
            val q = findInput.text.toString()
            if (q.isNotEmpty()) current?.session?.finder?.find(q, 1) // 1 = search backwards
        }
        findViewById<View>(R.id.findClose).setOnClickListener { closeFind() }
    }

    // ------------------------------------------------------------------ Tabs

    private fun newSession(private: Boolean): GeckoSession =
        if (private) GeckoSession(GeckoSessionSettings.Builder().usePrivateMode(true).build())
        else GeckoSession()

    private fun openTab(url: String?, private: Boolean = false, select: Boolean = true): Tab {
        val rt = runtime!!
        val tab = Tab(newSession(private), private)
        attach(tab)
        tab.session.open(rt)
        tabs.add(tab)
        if (select) selectTab(tabs.size - 1)
        if (url != null) {
            tab.url = url
            tab.session.loadUri(url)
        }
        updateUi()
        return tab
    }

    private fun selectTab(index: Int) {
        if (index !in tabs.indices) return
        currentIndex = index
        if (geckoView.session != null) geckoView.releaseSession()
        geckoView.setSession(tabs[index].session)
        videoFullscreen = false
        applyBarState()
        updateUi()
    }

    private fun closeTab(tab: Tab) {
        val idx = tabs.indexOf(tab)
        if (idx < 0) return
        val wasCurrent = idx == currentIndex
        tabs.removeAt(idx)
        if (tabs.isEmpty()) {
            geckoView.releaseSession()
            tab.session.close()
            currentIndex = -1
            openTab(HOME)
            return
        }
        if (wasCurrent) {
            geckoView.releaseSession()
            selectTab(minOf(idx, tabs.size - 1))
        } else if (idx < currentIndex) {
            currentIndex--
        }
        tab.session.close()
        updateUi()
    }

    private fun whenOpen(s: GeckoSession, tries: Int = 40, action: () -> Unit) {
        if (s.isOpen) action()
        else if (tries > 0) handler.postDelayed({ whenOpen(s, tries - 1, action) }, 50)
    }

    private fun attach(tab: Tab) {
        val s = tab.session

        s.progressDelegate = object : GeckoSession.ProgressDelegate {
            override fun onPageStart(session: GeckoSession, url: String) {
                tab.loading = true
                tab.progress = 5
                if (url.isNotEmpty()) tab.url = url
                refresh(tab)
            }

            override fun onPageStop(session: GeckoSession, success: Boolean) {
                tab.loading = false
                tab.progress = 100
                if (!tab.isPrivate && tab.url.startsWith("http")) store.addHistory(tab.title, tab.url)
                refresh(tab)
            }

            override fun onProgressChange(session: GeckoSession, progress: Int) {
                tab.progress = progress
                refresh(tab)
            }
        }

        s.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                tab.canBack = canGoBack
                refresh(tab)
            }

            override fun onCanGoForward(session: GeckoSession, canGoForward: Boolean) {
                tab.canForward = canGoForward
                refresh(tab)
            }

            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                if (url != null) {
                    tab.url = url
                    if (!tab.isPrivate && url.startsWith("http")) store.setLastUrl(url)
                    refresh(tab)
                }
            }

            // Links that open in a new window (target=_blank, window.open)
            override fun onNewSession(session: GeckoSession, uri: String): GeckoResult<GeckoSession>? {
                val child = newSession(tab.isPrivate)
                val childTab = Tab(child, tab.isPrivate)
                childTab.url = uri
                attach(childTab)
                tabs.add(childTab)
                runOnUiThread {
                    whenOpen(child) { selectTab(tabs.indexOf(childTab)) }
                }
                return GeckoResult.fromValue(child)
            }
        }

        s.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onTitleChange(session: GeckoSession, title: String?) {
                tab.title = title ?: ""
                refresh(tab)
            }

            override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                if (tab === current) {
                    videoFullscreen = fullScreen
                    applyBarState()
                }
            }

            override fun onCloseRequest(session: GeckoSession) {
                runOnUiThread { closeTab(tab) }
            }
        }
    }

    // ------------------------------------------------------------------ UI state

    private fun refresh(tab: Tab) {
        if (tab === current) runOnUiThread { updateUi() }
    }

    private fun displayUrl(t: Tab): String {
        if (t.url.isEmpty()) return ""
        val host = try { Uri.parse(t.url).host?.removePrefix("www.") } catch (_: Exception) { null }
        val base = if (!host.isNullOrEmpty()) host else t.url
        return if (t.isPrivate) "Private · $base" else base
    }

    private fun updateUi() {
        val t = current ?: return
        if (!urlText.hasFocus()) urlText.setText(displayUrl(t))
        lockIcon.setImageResource(
            when {
                t.url.startsWith("https") -> R.drawable.ic_lock
                t.url.isEmpty() -> R.drawable.ic_search
                else -> R.drawable.ic_info
            }
        )
        reloadBtn.setImageResource(if (t.loading) R.drawable.ic_close else R.drawable.ic_refresh)
        progress.visibility = if (t.loading) View.VISIBLE else View.INVISIBLE
        progress.progress = t.progress
        backBtn.alpha = if (t.canBack) 1f else 0.35f
        forwardBtn.alpha = if (t.canForward) 1f else 0.35f
        tabCount.text = tabs.size.toString()
    }

    private fun applyBarState() {
        val hide = barHidden || videoFullscreen
        val vis = if (hide) View.GONE else View.VISIBLE
        topBar.visibility = vis
        bottomBar.visibility = vis
        if (hide) findBar.visibility = View.GONE
        exitFullBtn.visibility = if (barHidden && !videoFullscreen) View.VISIBLE else View.GONE
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            if (hide) (View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
            else View.SYSTEM_UI_FLAG_VISIBLE
    }

    private fun go() {
        val text = urlText.text.toString().trim()
        if (text.isEmpty()) return
        val url = when {
            text.startsWith("http://") || text.startsWith("https://") -> text
            text.contains(" ") || !text.contains(".") -> store.searchUrl(text)
            else -> "https://$text"
        }
        current?.session?.loadUri(url)
        hideKeyboard()
        urlText.clearFocus()
        geckoView.requestFocus()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(urlText.windowToken, 0)
        imm.hideSoftInputFromWindow(findInput.windowToken, 0)
    }

    // ------------------------------------------------------------------ Menus

    private fun showMenu() {
        val t = current ?: return
        val bookmarked = store.isBookmarked(t.url)
        showSheet("Menu", listOf(
            Row(if (bookmarked) "Remove bookmark" else "Add bookmark",
                icon = if (bookmarked) R.drawable.ic_star else R.drawable.ic_star_border) {
                if (!t.url.startsWith("http")) toast("Nothing to bookmark yet")
                else if (bookmarked) { store.removeBookmark(t.url); toast("Bookmark removed") }
                else { store.addBookmark(t.title, t.url); toast("Bookmarked") }
            },
            Row("New tab", icon = R.drawable.ic_add) { openTab(HOME) },
            Row("New private tab", subtitle = "Nothing is saved", icon = R.drawable.ic_tabs) {
                openTab(HOME, private = true)
            },
            Row("Bookmarks", icon = R.drawable.ic_star) { showBookmarks() },
            Row("History", icon = R.drawable.ic_history) { showHistory() },
            Row("Add-ons", icon = R.drawable.ic_extension) { showAddons() },
            Row("Find in page", icon = R.drawable.ic_search) { openFind() },
            Row("Desktop site: " + if (t.desktop) "On" else "Off", icon = R.drawable.ic_desktop) {
                toggleDesktop(t)
            },
            Row("Share", icon = R.drawable.ic_share) { shareCurrent() },
            Row("Full screen", icon = R.drawable.ic_fullscreen) { barHidden = true; applyBarState() },
            Row("Settings", icon = R.drawable.ic_settings) { showSettings() }
        ))
    }

    private fun showTabs() {
        val rows = mutableListOf<Row>()
        rows.add(Row("New tab", icon = R.drawable.ic_add) { openTab(HOME) })
        tabs.forEachIndexed { i, t ->
            val title = if (t.title.isNotBlank()) t.title else if (t.url.isNotBlank()) t.url else "New tab"
            rows.add(Row(
                title = (if (t.isPrivate) "[Private] " else "") + title,
                subtitle = if (i == currentIndex) "Current tab" else displayUrl(t),
                icon = R.drawable.ic_tabs,
                trailingIcon = R.drawable.ic_close,
                onTrailing = { closeTab(t); if (tabs.size > 1) showTabs() },
                onClick = { selectTab(tabs.indexOf(t)) }
            ))
        }
        showSheet("Tabs (${tabs.size})", rows)
    }

    private fun showBookmarks() {
        val rows = store.bookmarks().map { e ->
            Row(e.title, subtitle = e.url, icon = R.drawable.ic_star,
                trailingIcon = R.drawable.ic_trash,
                onTrailing = { store.removeBookmark(e.url); showBookmarks() },
                onClick = { current?.session?.loadUri(e.url) })
        }
        showSheet("Bookmarks", rows, "No bookmarks yet. Open the menu and tap \"Add bookmark\".")
    }

    private fun showHistory() {
        val rows = mutableListOf<Row>()
        val items = store.history()
        if (items.isNotEmpty()) {
            rows.add(Row("Clear history", icon = R.drawable.ic_trash) {
                store.clearHistory(); toast("History cleared")
            })
        }
        items.forEach { e ->
            rows.add(Row(e.title, subtitle = e.url, icon = R.drawable.ic_history) {
                current?.session?.loadUri(e.url)
            })
        }
        showSheet("History", rows, "No history yet.")
    }

    private fun showSettings() {
        showSheet("Settings", listOf(
            Row("Search engine", subtitle = store.engineName(), icon = R.drawable.ic_search) {
                showEnginePicker()
            },
            Row("Clear cookies, cache and site data", subtitle = "Signs you out of websites",
                icon = R.drawable.ic_trash) { confirmClearData() }
        ))
    }

    private fun showEnginePicker() {
        showSheet("Search engine", Store.ENGINES.keys.map { name ->
            Row(name, subtitle = if (name == store.engineName()) "Selected" else null,
                icon = R.drawable.ic_search) {
                store.setEngine(name); toast("Search engine: $name")
            }
        })
    }

    private fun confirmClearData() {
        AlertDialog.Builder(this)
            .setTitle("Clear browsing data?")
            .setMessage("This removes cookies, cache and site data. You will be signed out of websites such as Google.")
            .setPositiveButton("Clear") { _, _ ->
                runtime?.storageController?.clearData(StorageController.ClearFlags.ALL)?.onDone(
                    { store.clearHistory(); toast("Browsing data cleared") },
                    { toast("Could not clear data: ${it.message}") }
                )
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun toggleDesktop(t: Tab) {
        t.desktop = !t.desktop
        val st = t.session.settings
        st.setUserAgentMode(
            if (t.desktop) GeckoSessionSettings.USER_AGENT_MODE_DESKTOP
            else GeckoSessionSettings.USER_AGENT_MODE_MOBILE
        )
        st.setViewportMode(
            if (t.desktop) GeckoSessionSettings.VIEWPORT_MODE_DESKTOP
            else GeckoSessionSettings.VIEWPORT_MODE_MOBILE
        )
        t.session.reload()
        toast(if (t.desktop) "Desktop site on" else "Desktop site off")
    }

    private fun shareCurrent() {
        val t = current ?: return
        if (!t.url.startsWith("http")) { toast("Nothing to share yet"); return }
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, t.url)
            putExtra(Intent.EXTRA_SUBJECT, t.title)
        }
        startActivity(Intent.createChooser(i, "Share link"))
    }

    private fun openFind() {
        findBar.visibility = View.VISIBLE
        findInput.requestFocus()
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(findInput, 0)
    }

    private fun closeFind() {
        current?.session?.finder?.clear()
        findInput.setText("")
        findBar.visibility = View.GONE
        hideKeyboard()
    }

    // ------------------------------------------------------------------ Add-ons

    private fun setupExtensions(rt: GeckoRuntime) {
        val controller = rt.webExtensionController
        controller.setPromptDelegate(buildPromptDelegate())
        // Built-in YouTube ad blocker (uBlock Origin)
        controller.ensureBuiltIn(UBLOCK_URI, UBLOCK_ID).onDone(
            { toast("uBlock Origin active") },
            { toast("Could not load uBlock Origin: ${it.message}") }
        )
    }

    private fun showAddons() {
        val controller = runtime?.webExtensionController ?: return
        controller.list().onDone(
            { list ->
                val addons = list ?: emptyList()
                val rows = mutableListOf<Row>()
                rows.add(Row("Add extension", subtitle = "Popular picks or an .xpi link",
                    icon = R.drawable.ic_add) { showAddMenu() })
                addons.forEach { ext ->
                    val name = ext.metaData?.name ?: ext.id
                    val builtIn = ext.id == UBLOCK_ID
                    rows.add(Row(
                        title = name,
                        subtitle = if (builtIn) "Built-in ad blocker" else "Version ${ext.metaData?.version ?: "?"}",
                        icon = R.drawable.ic_extension,
                        trailingIcon = if (builtIn) null else R.drawable.ic_trash,
                        onTrailing = if (builtIn) null else ({ confirmRemove(ext) }),
                        onClick = { }
                    ))
                }
                runOnUiThread { showSheet("Add-ons (${addons.size})", rows) }
            },
            { toast("Could not list add-ons: ${it.message}") }
        )
    }

    private fun confirmRemove(ext: WebExtension) {
        val name = ext.metaData?.name ?: ext.id
        AlertDialog.Builder(this)
            .setTitle("Remove $name?")
            .setPositiveButton("Remove") { _, _ ->
                runtime?.webExtensionController?.uninstall(ext)?.onDone(
                    { toast("Removed: $name"); showAddons() },
                    { toast("Remove failed: ${it.message}") }
                )
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showAddMenu() {
        val rows = mutableListOf<Row>()
        POPULAR.forEach { (name, link) ->
            rows.add(Row(name, icon = R.drawable.ic_extension) { installExtension(link) })
        }
        rows.add(Row("Custom .xpi link...", icon = R.drawable.ic_add) { showCustomInstallDialog() })
        showSheet("Add an extension", rows)
    }

    private fun showCustomInstallDialog() {
        val input = EditText(this).apply {
            hint = "https://.../extension.xpi"
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("Install Firefox extension")
            .setMessage("Paste a direct .xpi link (on addons.mozilla.org: long-press \"Add to Firefox\" and copy the link).")
            .setView(input)
            .setPositiveButton("Install") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isNotEmpty()) installExtension(url)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun installExtension(url: String) {
        toast("Installing...")
        runtime?.webExtensionController?.install(url)?.onDone(
            { toast("Installed: ${it?.metaData?.name ?: "extension"}") },
            { toast("Install failed: ${it.message}") }
        )
    }

    /**
     * PromptDelegate that approves extension install prompts. Built as a dynamic proxy so it
     * compiles against any GeckoView version (prompt method signatures differ between releases).
     */
    private fun buildPromptDelegate(): WebExtensionController.PromptDelegate {
        val handler = InvocationHandler { proxy, method, args ->
            when (method.name) {
                "hashCode" -> System.identityHashCode(proxy)
                "equals" -> proxy === args?.get(0)
                "toString" -> "ExtensionPromptDelegate"
                else -> {
                    if (method.returnType == GeckoResult::class.java) {
                        val argType = (method.genericReturnType as? ParameterizedType)
                            ?.actualTypeArguments?.firstOrNull() as? Class<*>
                        when {
                            argType == AllowOrDeny::class.java ->
                                GeckoResult.fromValue(AllowOrDeny.ALLOW)
                            argType != null && argType.simpleName == "PermissionPromptResponse" -> {
                                val ctor = argType.constructors.first()
                                val values = ctor.parameterTypes.indices.map { it != 1 }
                                GeckoResult.fromValue(ctor.newInstance(*values.toTypedArray()))
                            }
                            else -> null
                        }
                    } else null
                }
            }
        }
        return Proxy.newProxyInstance(
            WebExtensionController.PromptDelegate::class.java.classLoader,
            arrayOf(WebExtensionController.PromptDelegate::class.java),
            handler
        ) as WebExtensionController.PromptDelegate
    }

    // ------------------------------------------------------------------ Bottom sheet

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun selectableBackground(): Int {
        val out = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, out, true)
        return out.resourceId
    }

    private fun showSheet(title: String, rows: List<Row>, emptyText: String? = null) {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_sheet)
            setPadding(0, dp(10), 0, dp(12))
        }
        root.addView(View(this).apply {
            setBackgroundResource(R.drawable.bg_handle)
            layoutParams = LinearLayout.LayoutParams(dp(36), dp(4)).apply {
                gravity = Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(10)
            }
        })
        root.addView(TextView(this).apply {
            text = title
            setTextColor(getColor(R.color.text))
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(20), dp(4), dp(20), dp(8))
        })

        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (rows.isEmpty() && emptyText != null) {
            list.addView(TextView(this).apply {
                text = emptyText
                setTextColor(getColor(R.color.text_secondary))
                textSize = 14f
                setPadding(dp(20), dp(12), dp(20), dp(20))
            })
        }
        rows.forEach { row -> list.addView(buildRow(row, dialog)) }

        val scroll = ScrollView(this)
        scroll.addView(list)
        val maxH = (resources.displayMetrics.heightPixels * 0.62).toInt()
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            if (rows.size > 6) maxH else ViewGroup.LayoutParams.WRAP_CONTENT
        )
        root.addView(scroll, lp)

        dialog.setContentView(root)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
            setDimAmount(0.45f)
        }
        dialog.show()
    }

    private fun buildRow(row: Row, dialog: Dialog): View {
        val line = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(11), dp(8), dp(11))
            setBackgroundResource(selectableBackground())
            setOnClickListener { dialog.dismiss(); row.onClick() }
        }
        if (row.icon != null) {
            line.addView(ImageView(this).apply {
                setImageResource(row.icon)
                layoutParams = LinearLayout.LayoutParams(dp(24), dp(24)).apply { marginEnd = dp(16) }
            })
        }
        val texts = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        texts.addView(TextView(this).apply {
            text = row.title
            setTextColor(getColor(R.color.text))
            textSize = 16f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        if (!row.subtitle.isNullOrEmpty()) {
            texts.addView(TextView(this).apply {
                text = row.subtitle
                setTextColor(getColor(R.color.text_secondary))
                textSize = 12f
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
        }
        line.addView(texts)
        if (row.trailingIcon != null && row.onTrailing != null) {
            line.addView(ImageView(this).apply {
                setImageResource(row.trailingIcon)
                setPadding(dp(10), dp(10), dp(10), dp(10))
                setBackgroundResource(selectableBackground())
                layoutParams = LinearLayout.LayoutParams(dp(44), dp(44))
                setOnClickListener { dialog.dismiss(); row.onTrailing.invoke() }
            })
        }
        return line
    }

    // ------------------------------------------------------------------ Helpers

    private fun <T> GeckoResult<T>.onDone(ok: (T?) -> Unit, err: (Throwable) -> Unit) {
        this.then(
            GeckoResult.OnValueListener<T, Void> { ok(it); null },
            GeckoResult.OnExceptionListener<Void> { err(it); null }
        )
    }

    private fun toast(msg: String) =
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
}
