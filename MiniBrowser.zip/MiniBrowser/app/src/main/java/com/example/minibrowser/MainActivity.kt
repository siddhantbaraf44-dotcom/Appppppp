package com.example.minibrowser

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import org.mozilla.geckoview.GeckoResult
import org.mozilla.geckoview.GeckoRuntime
import org.mozilla.geckoview.GeckoSession
import org.mozilla.geckoview.GeckoView
import org.mozilla.geckoview.WebExtension
import org.mozilla.geckoview.WebExtensionController

class MainActivity : Activity() {

    companion object {
        private var runtime: GeckoRuntime? = null
        private const val HOME = "https://m.youtube.com"
        // uBlock Origin is unpacked into assets/extensions/ublock by the GitHub Action
        private const val UBLOCK_URI = "resource://android/assets/extensions/ublock/"
        private const val UBLOCK_ID = "uBlock0@raymondhill.net"
    }

    private lateinit var geckoView: GeckoView
    private lateinit var session: GeckoSession
    private lateinit var urlBar: EditText
    private lateinit var toolbar: View
    private var canGoBack = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        geckoView = findViewById(R.id.geckoview)
        urlBar = findViewById(R.id.urlBar)
        toolbar = findViewById(R.id.toolbar)

        val rt = runtime ?: GeckoRuntime.create(applicationContext).also { runtime = it }
        setupExtensions(rt)

        session = GeckoSession()
        session.navigationDelegate = object : GeckoSession.NavigationDelegate {
            override fun onCanGoBack(session: GeckoSession, canGoBack: Boolean) {
                this@MainActivity.canGoBack = canGoBack
            }

            override fun onLocationChange(
                session: GeckoSession,
                url: String?,
                perms: MutableList<GeckoSession.PermissionDelegate.ContentPermission>,
                hasUserGesture: Boolean
            ) {
                if (url != null && !urlBar.hasFocus()) urlBar.setText(url)
            }
        }
        session.contentDelegate = object : GeckoSession.ContentDelegate {
            override fun onFullScreen(session: GeckoSession, fullScreen: Boolean) {
                toolbar.visibility = if (fullScreen) View.GONE else View.VISIBLE
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility =
                    if (fullScreen) (View.SYSTEM_UI_FLAG_FULLSCREEN or
                            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY)
                    else View.SYSTEM_UI_FLAG_VISIBLE
            }
        }
        session.open(rt)
        geckoView.setSession(session)
        session.loadUri(HOME)

        urlBar.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_GO) { go(); true } else false
        }
        findViewById<Button>(R.id.goBtn).setOnClickListener { go() }
        findViewById<Button>(R.id.addonBtn).setOnClickListener { showAddonDialog() }
    }

    private fun setupExtensions(rt: GeckoRuntime) {
        val controller = rt.webExtensionController

        // Allows installing extensions from an .xpi URL.
        controller.promptDelegate = object : WebExtensionController.PromptDelegate {
            override fun onInstallPromptRequest(
                extension: WebExtension,
                permissions: Array<String>,
                origins: Array<String>
            ): GeckoResult<WebExtension.PermissionPromptResponse>? {
                return GeckoResult.fromValue(WebExtension.PermissionPromptResponse(true, false))
            }
        }

        // Built-in YouTube ad blocker (uBlock Origin)
        controller.ensureBuiltIn(UBLOCK_URI, UBLOCK_ID).then(
            GeckoResult.OnValueListener<WebExtension, Void> {
                toast("uBlock Origin active")
                null
            },
            GeckoResult.OnExceptionListener<Void> {
                toast("Could not load uBlock Origin: ${it.message}")
                null
            }
        )
    }

    private fun go() {
        val text = urlBar.text.toString().trim()
        if (text.isEmpty()) return
        val url = when {
            text.startsWith("http://") || text.startsWith("https://") -> text
            text.contains(" ") || !text.contains(".") ->
                "https://duckduckgo.com/?q=" + java.net.URLEncoder.encode(text, "UTF-8")
            else -> "https://$text"
        }
        session.loadUri(url)
        urlBar.clearFocus()
        geckoView.requestFocus()
    }

    private fun showAddonDialog() {
        val input = EditText(this).apply {
            hint = "https://.../extension.xpi"
            setSingleLine()
        }
        AlertDialog.Builder(this)
            .setTitle("Install Firefox extension")
            .setMessage("Paste a direct .xpi link (for example from addons.mozilla.org: right-click \"Add to Firefox\" > copy link).")
            .setView(input)
            .setPositiveButton("Install") { _, _ ->
                val url = input.text.toString().trim()
                if (url.isNotEmpty()) installExtension(url)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun installExtension(url: String) {
        runtime?.webExtensionController?.install(url)?.then(
            GeckoResult.OnValueListener<WebExtension, Void> {
                toast("Installed: ${it?.metaData?.name ?: "extension"}")
                null
            },
            GeckoResult.OnExceptionListener<Void> {
                toast("Install failed: ${it.message}")
                null
            }
        )
    }

    private fun toast(msg: String) =
        runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (canGoBack) session.goBack() else super.onBackPressed()
    }
}
