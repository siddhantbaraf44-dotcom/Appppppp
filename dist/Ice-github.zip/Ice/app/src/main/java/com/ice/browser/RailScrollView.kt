package com.ice.browser

import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ViewGroup
import android.widget.ScrollView

/**
 * Scroll container for the floating half-pill tabs. It only takes touches that land
 * on a button (including its slide offset); gaps and everything else fall through to the page.
 */
class RailScrollView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : ScrollView(context, attrs) {

    /** Upper limit for the rail's height, so the stack stays in the upper/middle part of the screen. */
    var maxHeightPx: Int = Int.MAX_VALUE
        set(value) {
            if (field != value) {
                field = value
                requestLayout()
            }
        }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val mode = MeasureSpec.getMode(heightMeasureSpec)
        if (mode == MeasureSpec.UNSPECIFIED || maxHeightPx == Int.MAX_VALUE) {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        } else {
            val cap = minOf(MeasureSpec.getSize(heightMeasureSpec), maxHeightPx)
            super.onMeasure(widthMeasureSpec, MeasureSpec.makeMeasureSpec(cap, MeasureSpec.AT_MOST))
        }
    }

    /** True when (x, y) in this view's coordinates is on a button. */
    fun hitsButton(x: Float, y: Float): Boolean {
        val col = getChildAt(0) as? ViewGroup ?: return false
        val cy = y + scrollY
        for (i in 0 until col.childCount) {
            val c = col.getChildAt(i)
            if (c.visibility != VISIBLE) continue
            val l = c.left + c.translationX
            val r = c.right + c.translationX
            if (x >= l && x <= r && cy >= c.top && cy <= c.bottom) return true
        }
        return false
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN && !hitsButton(ev.x, ev.y)) return false
        return super.dispatchTouchEvent(ev)
    }
}
