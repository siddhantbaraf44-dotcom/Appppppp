# GeckoView calls into Java through JNI and reflection, and ICE reads its prompt-delegate
# types by reflection (see buildPromptDelegate), so the engine's classes must stay as-is.
-keep class org.mozilla.** { *; }
-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*
-dontwarn org.mozilla.**
-dontwarn javax.annotation.**
