# GeckoView calls into Java through JNI and reflection, and ICE reads its prompt-delegate
# types by reflection (see buildPromptDelegate), so the engine's classes must stay as-is.
-keep class org.mozilla.** { *; }
-keepattributes Signature,InnerClasses,EnclosingMethod,*Annotation*
-dontwarn org.mozilla.**
-dontwarn javax.annotation.**
# Don't fail the build on references to optional classes that GeckoView's libraries mention but don't ship
-ignorewarnings
-dontwarn **
