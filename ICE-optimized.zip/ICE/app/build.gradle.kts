plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

val geckoVersion: String by project

android {
    namespace = "com.example.minibrowser"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ice.browser"
        minSdk = 23
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }

    // One APK per CPU type. GeckoView's native engine is by far the biggest part of the app,
    // so a phone only downloads/installs the one library set it needs (install ~halved).
    // Install the arm64-v8a APK on any phone from the last ~8 years.
    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a")
            isUniversalApk = false
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true        // R8: removes unused code, smaller dex, faster class loading
            isShrinkResources = true      // removes unused drawables/layouts
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Personal use: signed with the debug key so the APK installs without a keystore.
            signingConfig = signingConfigs.getByName("debug")
            isDebuggable = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    packaging { jniLibs { useLegacyPackaging = true } }

    lint { checkReleaseBuilds = false }
}

dependencies {
    implementation("org.mozilla.geckoview:geckoview-omni:$geckoVersion")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
}
