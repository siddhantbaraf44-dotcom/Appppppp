# ICE performance notes

## Bottlenecks found
| Area | Problem | Fix |
|---|---|---|
| Build | Only a **debug** APK was built: no R8, no resource shrinking, both CPU types packed in one APK | Release build with R8 + `shrinkResources`, one APK per CPU (`arm64-v8a`, `armeabi-v7a`) |
| Startup | Every restored tab opened an engine session (up to 20) and rebuilt the tab strip once per tab | Background tabs are not opened until tapped; the strip is built once |
| Memory | Background tabs stayed alive under memory pressure | `onTrimMemory` closes background tabs (they reload when tapped); skipped while audio plays, for private and loading tabs |
| Storage | Bookmarks/history/shortcuts JSON was re-parsed on every menu open, bookmark check and page load; history rewritten even when unchanged | Parsed once, served from memory; no write when the top entry is unchanged |
| Network | Site icons re-downloaded on every cold start | 14-day on-disk icon cache |
| Build speed | Gradle caching/parallel off | Enabled in `gradle.properties` |

## Install
Install `app-arm64-v8a-release.apk` on any modern phone (`armeabi-v7a` only for old 32-bit phones).
The release APK is signed with the debug key, which CI regenerates, so uninstall the old ICE before installing a new CI build, or add your own keystore later.

## Measuring (do this before/after each change)
- APK size: `ls -l app/build/outputs/apk/release/`
- Cold start: `adb shell am start -W -n com.ice.browser/com.example.minibrowser.MainActivity` (look at `TotalTime`)
- Memory: `adb shell dumpsys meminfo com.ice.browser` (watch "TOTAL PSS" with 1, 5 and 20 tabs)
- Frame jank: `adb shell dumpsys gfxinfo com.ice.browser` (janky frame %)
- Battery: `adb shell dumpsys batterystats com.ice.browser` after a day of normal use
- Android Studio Profiler: CPU and memory while switching tabs and typing in the address bar
- Debug builds log StrictMode violations (disk/network on the main thread, leaks): `adb logcat -s StrictMode`

## Ongoing monitoring
1. Record APK size, cold-start time and PSS with 5 tabs for each release in a table.
2. Test on at least one low-end phone (2-3 GB RAM, Android 8-10) and one current phone; check the Android Studio Device Manager "low RAM" emulator profile too.
3. Add Firebase Crashlytics + Performance Monitoring (you already use Firebase) for crashes, ANRs and startup traces on your own device.
4. Pin `geckoVersion` to an exact version once you know which one you like (`128.+` picks up new builds silently and can change speed/size between CI runs). Update Gecko deliberately and re-measure.
5. Keep uBlock's filter lists to the defaults; extra lists cost memory and page load time.
