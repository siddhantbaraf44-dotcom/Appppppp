# Ice (GeckoView + uBlock Origin)

Android browser on Firefox's Gecko engine with a built-in ad blocker (uBlock Origin, also active in Incognito tabs).

## Build with GitHub Actions
1. Push this project to a GitHub repo (keep `.github/workflows/build.yml`).
2. Actions > Build APK runs automatically. Download the APK from Artifacts.

## Features
- Light/dark UI that follows the system theme; Chrome-style top bar (Home, address bar, Tabs, Menu)
- Tab stack on the left edge, in the upper/middle part of the screen: tap to switch, long-press to close, "+" for a new tab; it scrolls when there are many tabs
- Tabs are restored when the app restarts (Incognito tabs are not saved); only the selected tab loads at start
- Tab switcher grid, private tabs, links that open in new tabs (Back closes a tab that was opened from a link)
- Bookmarks, history, find in page, desktop site, share, downloads, full screen (only the exit button leaves it)
- Background play (Settings): the foreground service starts only while audio is actually playing
- Search-engine dropdown (DuckDuckGo, Google, Bing, Brave, Yahoo, Ecosia, Startpage, YouTube, Wikipedia) and optional search suggestions (off in Incognito)
- Home page with your own shortcuts; custom home page in Settings
- Add-ons manager (uBlock Origin built in; install/remove others)
- Set as default browser (opens http/https links from other apps)

All data (bookmarks, history, settings, open tabs) stays on the device; nothing is synced to any server.
